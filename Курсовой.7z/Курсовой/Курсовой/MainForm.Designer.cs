﻿namespace Курсовой
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.product_client_id = new System.Windows.Forms.TextBox();
            this.quantity_client = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.addOrders = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.find_id_orders = new System.Windows.Forms.TextBox();
            this.findOrders = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ascOrders = new System.Windows.Forms.RadioButton();
            this.descOrders = new System.Windows.Forms.RadioButton();
            this.sortOrders = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.deleteOrders = new System.Windows.Forms.Button();
            this.editOrders = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ordersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.практика_КудаевDataSetOrders = new Курсовой.Практика_КудаевDataSetOrders();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.order_id = new System.Windows.Forms.TextBox();
            this.order_status = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.order_client_id = new System.Windows.Forms.TextBox();
            this.order_product_id = new System.Windows.Forms.TextBox();
            this.order_quantity = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productidDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.operationtypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.enddateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.responsibleemployeeidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productionOperationsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.практика_КудаевDataSetProduction_Operations = new Курсовой.Практика_КудаевDataSetProduction_Operations();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productidDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.locationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.warehouseStocksBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.практика_КудаевDataSetWarehouse_Stocks = new Курсовой.Практика_КудаевDataSetWarehouse_Stocks();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loginDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passwordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.практика_КудаевDataSetUsers1 = new Курсовой.Практика_КудаевDataSetUsers1();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.практика_КудаевDataSetProducts = new Курсовой.Практика_КудаевDataSetProducts();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchasedateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchasedeliveryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalcostDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalitemsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productidDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchasesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.практика_КудаевDataSetPurchases = new Курсовой.Практика_КудаевDataSetPurchases();
            this.SignOut = new System.Windows.Forms.Button();
            this.SettingsColor = new System.Windows.Forms.Button();
            this.ordersTableAdapter = new Курсовой.Практика_КудаевDataSetOrdersTableAdapters.OrdersTableAdapter();
            this.production_OperationsTableAdapter = new Курсовой.Практика_КудаевDataSetProduction_OperationsTableAdapters.Production_OperationsTableAdapter();
            this.warehouse_StocksTableAdapter = new Курсовой.Практика_КудаевDataSetWarehouse_StocksTableAdapters.Warehouse_StocksTableAdapter();
            this.usersTableAdapter = new Курсовой.Практика_КудаевDataSetUsers1TableAdapters.UsersTableAdapter();
            this.productsTableAdapter = new Курсовой.Практика_КудаевDataSetProductsTableAdapters.ProductsTableAdapter();
            this.purchasesTableAdapter = new Курсовой.Практика_КудаевDataSetPurchasesTableAdapters.PurchasesTableAdapter();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.operation_id = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.operation_order_id = new System.Windows.Forms.TextBox();
            this.operation_product_id = new System.Windows.Forms.TextBox();
            this.operation_type = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.operation_resp = new System.Windows.Forms.TextBox();
            this.addOperations = new System.Windows.Forms.Button();
            this.editOperations = new System.Windows.Forms.Button();
            this.deleteOperations = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ascOperations = new System.Windows.Forms.RadioButton();
            this.descOperations = new System.Windows.Forms.RadioButton();
            this.sortOperations = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.find_id_operations = new System.Windows.Forms.TextBox();
            this.findOperations = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.panel4 = new System.Windows.Forms.Panel();
            this.stocks_location = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.stocks_id = new System.Windows.Forms.TextBox();
            this.stocks_product_id = new System.Windows.Forms.TextBox();
            this.stocks_quantity = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.ascStocks = new System.Windows.Forms.RadioButton();
            this.descStocks = new System.Windows.Forms.RadioButton();
            this.sortStocks = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.addStocks = new System.Windows.Forms.Button();
            this.editStocks = new System.Windows.Forms.Button();
            this.deleteStocks = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.find_id_stocks = new System.Windows.Forms.TextBox();
            this.findStocks = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.user_password = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.user_id = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.user_login = new System.Windows.Forms.TextBox();
            this.user_role = new System.Windows.Forms.ComboBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.ascUsers = new System.Windows.Forms.RadioButton();
            this.descUsers = new System.Windows.Forms.RadioButton();
            this.sortUsers = new System.Windows.Forms.Button();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.addUsers = new System.Windows.Forms.Button();
            this.editUsers = new System.Windows.Forms.Button();
            this.deleteUsers = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.find_id_users = new System.Windows.Forms.TextBox();
            this.findUsers = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.product_price = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.product_id = new System.Windows.Forms.TextBox();
            this.product_desc = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.product_name = new System.Windows.Forms.TextBox();
            this.addProducts = new System.Windows.Forms.Button();
            this.editProducts = new System.Windows.Forms.Button();
            this.deleteProducts = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.ascProducts = new System.Windows.Forms.RadioButton();
            this.descProducts = new System.Windows.Forms.RadioButton();
            this.sortProducts = new System.Windows.Forms.Button();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.find_id_products = new System.Windows.Forms.TextBox();
            this.findProducts = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.purchase_product_id = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.purchase_id = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.purchase_sup = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.addPurchases = new System.Windows.Forms.Button();
            this.editPurchases = new System.Windows.Forms.Button();
            this.deletePurchases = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.ascPurchases = new System.Windows.Forms.RadioButton();
            this.descPurchases = new System.Windows.Forms.RadioButton();
            this.sortPurchases = new System.Windows.Forms.Button();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.find_id_purchases = new System.Windows.Forms.TextBox();
            this.findPurchases = new System.Windows.Forms.Button();
            this.purchase_total = new System.Windows.Forms.TextBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.SettingsStyle = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.SettingsStyleButtons = new System.Windows.Forms.Button();
            this.fontDialog2 = new System.Windows.Forms.FontDialog();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.практика_КудаевDataSetOrders)).BeginInit();
            this.panel1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productionOperationsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.практика_КудаевDataSetProduction_Operations)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.warehouseStocksBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.практика_КудаевDataSetWarehouse_Stocks)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.практика_КудаевDataSetUsers1)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.практика_КудаевDataSetProducts)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchasesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.практика_КудаевDataSetPurchases)).BeginInit();
            this.panel3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.panel6.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.panel7.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(776, 498);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Red;
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.addOrders);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.deleteOrders);
            this.tabPage1.Controls.Add(this.editOrders);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(768, 472);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Заказы";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.Controls.Add(this.product_client_id);
            this.panel2.Controls.Add(this.quantity_client);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label10);
            this.panel2.ForeColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(7, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(113, 115);
            this.panel2.TabIndex = 17;
            // 
            // product_client_id
            // 
            this.product_client_id.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.product_client_id.Location = new System.Drawing.Point(7, 26);
            this.product_client_id.Name = "product_client_id";
            this.product_client_id.Size = new System.Drawing.Size(100, 26);
            this.product_client_id.TabIndex = 9;
            this.product_client_id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // quantity_client
            // 
            this.quantity_client.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.quantity_client.Location = new System.Drawing.Point(7, 76);
            this.quantity_client.Name = "quantity_client";
            this.quantity_client.Size = new System.Drawing.Size(100, 26);
            this.quantity_client.TabIndex = 11;
            this.quantity_client.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(4, 5);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 18);
            this.label9.TabIndex = 8;
            this.label9.Text = "id продукта";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(4, 55);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 18);
            this.label10.TabIndex = 10;
            this.label10.Text = "Количество";
            // 
            // addOrders
            // 
            this.addOrders.BackColor = System.Drawing.Color.White;
            this.addOrders.FlatAppearance.BorderSize = 0;
            this.addOrders.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addOrders.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addOrders.Location = new System.Drawing.Point(7, 122);
            this.addOrders.Name = "addOrders";
            this.addOrders.Size = new System.Drawing.Size(113, 35);
            this.addOrders.TabIndex = 17;
            this.addOrders.Text = "Добавить";
            this.addOrders.UseVisualStyleBackColor = false;
            this.addOrders.Click += new System.EventHandler(this.addOrders_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.find_id_orders);
            this.groupBox2.Controls.Add(this.findOrders);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox2.Location = new System.Drawing.Point(532, 205);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(230, 68);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Поиск по id";
            // 
            // find_id_orders
            // 
            this.find_id_orders.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.find_id_orders.Location = new System.Drawing.Point(6, 28);
            this.find_id_orders.Name = "find_id_orders";
            this.find_id_orders.Size = new System.Drawing.Size(100, 26);
            this.find_id_orders.TabIndex = 16;
            this.find_id_orders.TextChanged += new System.EventHandler(this.find_id_orders_TextChanged);
            this.find_id_orders.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // findOrders
            // 
            this.findOrders.BackColor = System.Drawing.Color.White;
            this.findOrders.Enabled = false;
            this.findOrders.FlatAppearance.BorderSize = 0;
            this.findOrders.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.findOrders.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold);
            this.findOrders.Location = new System.Drawing.Point(112, 28);
            this.findOrders.Name = "findOrders";
            this.findOrders.Size = new System.Drawing.Size(31, 26);
            this.findOrders.TabIndex = 1;
            this.findOrders.Text = "L";
            this.findOrders.UseVisualStyleBackColor = false;
            this.findOrders.Click += new System.EventHandler(this.findOrders_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ascOrders);
            this.groupBox1.Controls.Add(this.descOrders);
            this.groupBox1.Controls.Add(this.sortOrders);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.Location = new System.Drawing.Point(188, 205);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(328, 247);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Сортировка по";
            // 
            // ascOrders
            // 
            this.ascOrders.AutoSize = true;
            this.ascOrders.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ascOrders.Location = new System.Drawing.Point(6, 88);
            this.ascOrders.Name = "ascOrders";
            this.ascOrders.Size = new System.Drawing.Size(145, 22);
            this.ascOrders.TabIndex = 3;
            this.ascOrders.TabStop = true;
            this.ascOrders.Text = "По возрастанию";
            this.ascOrders.UseVisualStyleBackColor = true;
            // 
            // descOrders
            // 
            this.descOrders.AutoSize = true;
            this.descOrders.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.descOrders.Location = new System.Drawing.Point(6, 60);
            this.descOrders.Name = "descOrders";
            this.descOrders.Size = new System.Drawing.Size(124, 22);
            this.descOrders.TabIndex = 2;
            this.descOrders.TabStop = true;
            this.descOrders.Text = "По убыванию";
            this.descOrders.UseVisualStyleBackColor = true;
            this.descOrders.CheckedChanged += new System.EventHandler(this.descOrders_CheckedChanged);
            // 
            // sortOrders
            // 
            this.sortOrders.BackColor = System.Drawing.Color.White;
            this.sortOrders.FlatAppearance.BorderSize = 0;
            this.sortOrders.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sortOrders.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold);
            this.sortOrders.Location = new System.Drawing.Point(133, 28);
            this.sortOrders.Name = "sortOrders";
            this.sortOrders.Size = new System.Drawing.Size(31, 26);
            this.sortOrders.TabIndex = 1;
            this.sortOrders.Text = "L";
            this.sortOrders.UseVisualStyleBackColor = false;
            this.sortOrders.Click += new System.EventHandler(this.sortOrders_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "id",
            "id клиента",
            "id продукта",
            "Количество",
            "Статус"});
            this.comboBox1.Location = new System.Drawing.Point(6, 28);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 26);
            this.comboBox1.TabIndex = 0;
            // 
            // deleteOrders
            // 
            this.deleteOrders.BackColor = System.Drawing.Color.White;
            this.deleteOrders.FlatAppearance.BorderSize = 0;
            this.deleteOrders.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteOrders.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.deleteOrders.Location = new System.Drawing.Point(126, 163);
            this.deleteOrders.Name = "deleteOrders";
            this.deleteOrders.Size = new System.Drawing.Size(113, 35);
            this.deleteOrders.TabIndex = 2;
            this.deleteOrders.Text = "Удалить";
            this.deleteOrders.UseVisualStyleBackColor = false;
            this.deleteOrders.Click += new System.EventHandler(this.deleteOrders_Click);
            // 
            // editOrders
            // 
            this.editOrders.BackColor = System.Drawing.Color.White;
            this.editOrders.FlatAppearance.BorderSize = 0;
            this.editOrders.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.editOrders.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.editOrders.Location = new System.Drawing.Point(7, 163);
            this.editOrders.Name = "editOrders";
            this.editOrders.Size = new System.Drawing.Size(113, 35);
            this.editOrders.TabIndex = 1;
            this.editOrders.Text = "Изменить";
            this.editOrders.UseVisualStyleBackColor = false;
            this.editOrders.Click += new System.EventHandler(this.editOrders_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.clientidDataGridViewTextBoxColumn,
            this.productidDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.ordersBindingSource;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.Location = new System.Drawing.Point(6, 7);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(756, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.HeaderText = "id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // clientidDataGridViewTextBoxColumn
            // 
            this.clientidDataGridViewTextBoxColumn.DataPropertyName = "client_id";
            this.clientidDataGridViewTextBoxColumn.HeaderText = "client_id";
            this.clientidDataGridViewTextBoxColumn.Name = "clientidDataGridViewTextBoxColumn";
            // 
            // productidDataGridViewTextBoxColumn
            // 
            this.productidDataGridViewTextBoxColumn.DataPropertyName = "product_id";
            this.productidDataGridViewTextBoxColumn.HeaderText = "product_id";
            this.productidDataGridViewTextBoxColumn.Name = "productidDataGridViewTextBoxColumn";
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "quantity";
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            // 
            // ordersBindingSource
            // 
            this.ordersBindingSource.DataMember = "Orders";
            this.ordersBindingSource.DataSource = this.практика_КудаевDataSetOrders;
            // 
            // практика_КудаевDataSetOrders
            // 
            this.практика_КудаевDataSetOrders.DataSetName = "Практика_КудаевDataSetOrders";
            this.практика_КудаевDataSetOrders.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.order_id);
            this.panel1.Controls.Add(this.order_status);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.order_client_id);
            this.panel1.Controls.Add(this.order_product_id);
            this.panel1.Controls.Add(this.order_quantity);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.ForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(3, 204);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(117, 253);
            this.panel1.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(4, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "id";
            // 
            // order_id
            // 
            this.order_id.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.order_id.Location = new System.Drawing.Point(4, 22);
            this.order_id.Name = "order_id";
            this.order_id.Size = new System.Drawing.Size(100, 26);
            this.order_id.TabIndex = 5;
            this.order_id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // order_status
            // 
            this.order_status.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.order_status.Location = new System.Drawing.Point(4, 222);
            this.order_status.Name = "order_status";
            this.order_status.Size = new System.Drawing.Size(100, 26);
            this.order_status.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(4, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 18);
            this.label3.TabIndex = 6;
            this.label3.Text = "id клиента";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(4, 201);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 18);
            this.label5.TabIndex = 12;
            this.label5.Text = "Статус";
            // 
            // order_client_id
            // 
            this.order_client_id.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.order_client_id.Location = new System.Drawing.Point(4, 72);
            this.order_client_id.Name = "order_client_id";
            this.order_client_id.Size = new System.Drawing.Size(100, 26);
            this.order_client_id.TabIndex = 7;
            this.order_client_id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // order_product_id
            // 
            this.order_product_id.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.order_product_id.Location = new System.Drawing.Point(4, 122);
            this.order_product_id.Name = "order_product_id";
            this.order_product_id.Size = new System.Drawing.Size(100, 26);
            this.order_product_id.TabIndex = 9;
            this.order_product_id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // order_quantity
            // 
            this.order_quantity.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.order_quantity.Location = new System.Drawing.Point(4, 172);
            this.order_quantity.Name = "order_quantity";
            this.order_quantity.Size = new System.Drawing.Size(100, 26);
            this.order_quantity.TabIndex = 11;
            this.order_quantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(4, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 18);
            this.label2.TabIndex = 8;
            this.label2.Text = "id продукта";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(4, 151);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 18);
            this.label4.TabIndex = 10;
            this.label4.Text = "Количество";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Red;
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.deleteOperations);
            this.tabPage2.Controls.Add(this.editOperations);
            this.tabPage2.Controls.Add(this.addOperations);
            this.tabPage2.Controls.Add(this.panel3);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(768, 472);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Производственные операции";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn1,
            this.orderidDataGridViewTextBoxColumn,
            this.productidDataGridViewTextBoxColumn1,
            this.operationtypeDataGridViewTextBoxColumn,
            this.enddateDataGridViewTextBoxColumn,
            this.responsibleemployeeidDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.productionOperationsBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(7, 7);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(755, 150);
            this.dataGridView2.TabIndex = 0;
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "id";
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            this.idDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // orderidDataGridViewTextBoxColumn
            // 
            this.orderidDataGridViewTextBoxColumn.DataPropertyName = "order_id";
            this.orderidDataGridViewTextBoxColumn.HeaderText = "order_id";
            this.orderidDataGridViewTextBoxColumn.Name = "orderidDataGridViewTextBoxColumn";
            // 
            // productidDataGridViewTextBoxColumn1
            // 
            this.productidDataGridViewTextBoxColumn1.DataPropertyName = "product_id";
            this.productidDataGridViewTextBoxColumn1.HeaderText = "product_id";
            this.productidDataGridViewTextBoxColumn1.Name = "productidDataGridViewTextBoxColumn1";
            // 
            // operationtypeDataGridViewTextBoxColumn
            // 
            this.operationtypeDataGridViewTextBoxColumn.DataPropertyName = "operation_type";
            this.operationtypeDataGridViewTextBoxColumn.HeaderText = "operation_type";
            this.operationtypeDataGridViewTextBoxColumn.Name = "operationtypeDataGridViewTextBoxColumn";
            // 
            // enddateDataGridViewTextBoxColumn
            // 
            this.enddateDataGridViewTextBoxColumn.DataPropertyName = "end_date";
            this.enddateDataGridViewTextBoxColumn.HeaderText = "end_date";
            this.enddateDataGridViewTextBoxColumn.Name = "enddateDataGridViewTextBoxColumn";
            // 
            // responsibleemployeeidDataGridViewTextBoxColumn
            // 
            this.responsibleemployeeidDataGridViewTextBoxColumn.DataPropertyName = "responsible_employee_id";
            this.responsibleemployeeidDataGridViewTextBoxColumn.HeaderText = "responsible_employee_id";
            this.responsibleemployeeidDataGridViewTextBoxColumn.Name = "responsibleemployeeidDataGridViewTextBoxColumn";
            // 
            // productionOperationsBindingSource
            // 
            this.productionOperationsBindingSource.DataMember = "Production_Operations";
            this.productionOperationsBindingSource.DataSource = this.практика_КудаевDataSetProduction_Operations;
            // 
            // практика_КудаевDataSetProduction_Operations
            // 
            this.практика_КудаевDataSetProduction_Operations.DataSetName = "Практика_КудаевDataSetProduction_Operations";
            this.практика_КудаевDataSetProduction_Operations.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Red;
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Controls.Add(this.deleteStocks);
            this.tabPage3.Controls.Add(this.editStocks);
            this.tabPage3.Controls.Add(this.addStocks);
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Controls.Add(this.panel4);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(768, 472);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Складские запасы";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn2,
            this.productidDataGridViewTextBoxColumn2,
            this.quantityDataGridViewTextBoxColumn1,
            this.locationDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.warehouseStocksBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(3, 3);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(762, 150);
            this.dataGridView3.TabIndex = 0;
            // 
            // idDataGridViewTextBoxColumn2
            // 
            this.idDataGridViewTextBoxColumn2.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn2.HeaderText = "id";
            this.idDataGridViewTextBoxColumn2.Name = "idDataGridViewTextBoxColumn2";
            this.idDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // productidDataGridViewTextBoxColumn2
            // 
            this.productidDataGridViewTextBoxColumn2.DataPropertyName = "product_id";
            this.productidDataGridViewTextBoxColumn2.HeaderText = "product_id";
            this.productidDataGridViewTextBoxColumn2.Name = "productidDataGridViewTextBoxColumn2";
            // 
            // quantityDataGridViewTextBoxColumn1
            // 
            this.quantityDataGridViewTextBoxColumn1.DataPropertyName = "quantity";
            this.quantityDataGridViewTextBoxColumn1.HeaderText = "quantity";
            this.quantityDataGridViewTextBoxColumn1.Name = "quantityDataGridViewTextBoxColumn1";
            // 
            // locationDataGridViewTextBoxColumn
            // 
            this.locationDataGridViewTextBoxColumn.DataPropertyName = "location";
            this.locationDataGridViewTextBoxColumn.HeaderText = "location";
            this.locationDataGridViewTextBoxColumn.Name = "locationDataGridViewTextBoxColumn";
            // 
            // warehouseStocksBindingSource
            // 
            this.warehouseStocksBindingSource.DataMember = "Warehouse_Stocks";
            this.warehouseStocksBindingSource.DataSource = this.практика_КудаевDataSetWarehouse_Stocks;
            // 
            // практика_КудаевDataSetWarehouse_Stocks
            // 
            this.практика_КудаевDataSetWarehouse_Stocks.DataSetName = "Практика_КудаевDataSetWarehouse_Stocks";
            this.практика_КудаевDataSetWarehouse_Stocks.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Red;
            this.tabPage4.Controls.Add(this.groupBox8);
            this.tabPage4.Controls.Add(this.deleteUsers);
            this.tabPage4.Controls.Add(this.editUsers);
            this.tabPage4.Controls.Add(this.addUsers);
            this.tabPage4.Controls.Add(this.groupBox7);
            this.tabPage4.Controls.Add(this.panel5);
            this.tabPage4.Controls.Add(this.dataGridView4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(768, 472);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Пользователи";
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn3,
            this.roleDataGridViewTextBoxColumn,
            this.loginDataGridViewTextBoxColumn,
            this.passwordDataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.usersBindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(3, 3);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(762, 150);
            this.dataGridView4.TabIndex = 0;
            // 
            // idDataGridViewTextBoxColumn3
            // 
            this.idDataGridViewTextBoxColumn3.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn3.HeaderText = "id";
            this.idDataGridViewTextBoxColumn3.Name = "idDataGridViewTextBoxColumn3";
            this.idDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // roleDataGridViewTextBoxColumn
            // 
            this.roleDataGridViewTextBoxColumn.DataPropertyName = "role";
            this.roleDataGridViewTextBoxColumn.HeaderText = "role";
            this.roleDataGridViewTextBoxColumn.Name = "roleDataGridViewTextBoxColumn";
            // 
            // loginDataGridViewTextBoxColumn
            // 
            this.loginDataGridViewTextBoxColumn.DataPropertyName = "login";
            this.loginDataGridViewTextBoxColumn.HeaderText = "login";
            this.loginDataGridViewTextBoxColumn.Name = "loginDataGridViewTextBoxColumn";
            // 
            // passwordDataGridViewTextBoxColumn
            // 
            this.passwordDataGridViewTextBoxColumn.DataPropertyName = "password";
            this.passwordDataGridViewTextBoxColumn.HeaderText = "password";
            this.passwordDataGridViewTextBoxColumn.Name = "passwordDataGridViewTextBoxColumn";
            // 
            // usersBindingSource
            // 
            this.usersBindingSource.DataMember = "Users";
            this.usersBindingSource.DataSource = this.практика_КудаевDataSetUsers1;
            // 
            // практика_КудаевDataSetUsers1
            // 
            this.практика_КудаевDataSetUsers1.DataSetName = "Практика_КудаевDataSetUsers1";
            this.практика_КудаевDataSetUsers1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Red;
            this.tabPage5.Controls.Add(this.groupBox10);
            this.tabPage5.Controls.Add(this.groupBox9);
            this.tabPage5.Controls.Add(this.deleteProducts);
            this.tabPage5.Controls.Add(this.editProducts);
            this.tabPage5.Controls.Add(this.addProducts);
            this.tabPage5.Controls.Add(this.panel6);
            this.tabPage5.Controls.Add(this.dataGridView5);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(768, 472);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Продукция";
            // 
            // dataGridView5
            // 
            this.dataGridView5.AutoGenerateColumns = false;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn4,
            this.nameDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn});
            this.dataGridView5.DataSource = this.productsBindingSource;
            this.dataGridView5.Location = new System.Drawing.Point(3, 3);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.Size = new System.Drawing.Size(762, 150);
            this.dataGridView5.TabIndex = 0;
            // 
            // idDataGridViewTextBoxColumn4
            // 
            this.idDataGridViewTextBoxColumn4.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn4.HeaderText = "id";
            this.idDataGridViewTextBoxColumn4.Name = "idDataGridViewTextBoxColumn4";
            this.idDataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "description";
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            // 
            // productsBindingSource
            // 
            this.productsBindingSource.DataMember = "Products";
            this.productsBindingSource.DataSource = this.практика_КудаевDataSetProducts;
            // 
            // практика_КудаевDataSetProducts
            // 
            this.практика_КудаевDataSetProducts.DataSetName = "Практика_КудаевDataSetProducts";
            this.практика_КудаевDataSetProducts.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.Red;
            this.tabPage6.Controls.Add(this.groupBox12);
            this.tabPage6.Controls.Add(this.groupBox11);
            this.tabPage6.Controls.Add(this.deletePurchases);
            this.tabPage6.Controls.Add(this.editPurchases);
            this.tabPage6.Controls.Add(this.addPurchases);
            this.tabPage6.Controls.Add(this.panel7);
            this.tabPage6.Controls.Add(this.dataGridView6);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(768, 472);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Покупки";
            // 
            // dataGridView6
            // 
            this.dataGridView6.AutoGenerateColumns = false;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn5,
            this.purchasedateDataGridViewTextBoxColumn,
            this.purchasedeliveryDataGridViewTextBoxColumn,
            this.supplierDataGridViewTextBoxColumn,
            this.totalcostDataGridViewTextBoxColumn,
            this.totalitemsDataGridViewTextBoxColumn,
            this.productidDataGridViewTextBoxColumn3});
            this.dataGridView6.DataSource = this.purchasesBindingSource;
            this.dataGridView6.Location = new System.Drawing.Point(3, 3);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.Size = new System.Drawing.Size(762, 150);
            this.dataGridView6.TabIndex = 0;
            // 
            // idDataGridViewTextBoxColumn5
            // 
            this.idDataGridViewTextBoxColumn5.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn5.HeaderText = "id";
            this.idDataGridViewTextBoxColumn5.Name = "idDataGridViewTextBoxColumn5";
            this.idDataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // purchasedateDataGridViewTextBoxColumn
            // 
            this.purchasedateDataGridViewTextBoxColumn.DataPropertyName = "purchase_date";
            this.purchasedateDataGridViewTextBoxColumn.HeaderText = "purchase_date";
            this.purchasedateDataGridViewTextBoxColumn.Name = "purchasedateDataGridViewTextBoxColumn";
            // 
            // purchasedeliveryDataGridViewTextBoxColumn
            // 
            this.purchasedeliveryDataGridViewTextBoxColumn.DataPropertyName = "purchase_delivery";
            this.purchasedeliveryDataGridViewTextBoxColumn.HeaderText = "purchase_delivery";
            this.purchasedeliveryDataGridViewTextBoxColumn.Name = "purchasedeliveryDataGridViewTextBoxColumn";
            // 
            // supplierDataGridViewTextBoxColumn
            // 
            this.supplierDataGridViewTextBoxColumn.DataPropertyName = "supplier";
            this.supplierDataGridViewTextBoxColumn.HeaderText = "supplier";
            this.supplierDataGridViewTextBoxColumn.Name = "supplierDataGridViewTextBoxColumn";
            // 
            // totalcostDataGridViewTextBoxColumn
            // 
            this.totalcostDataGridViewTextBoxColumn.DataPropertyName = "total_cost";
            this.totalcostDataGridViewTextBoxColumn.HeaderText = "total_cost";
            this.totalcostDataGridViewTextBoxColumn.Name = "totalcostDataGridViewTextBoxColumn";
            // 
            // totalitemsDataGridViewTextBoxColumn
            // 
            this.totalitemsDataGridViewTextBoxColumn.DataPropertyName = "total_items";
            this.totalitemsDataGridViewTextBoxColumn.HeaderText = "total_items";
            this.totalitemsDataGridViewTextBoxColumn.Name = "totalitemsDataGridViewTextBoxColumn";
            // 
            // productidDataGridViewTextBoxColumn3
            // 
            this.productidDataGridViewTextBoxColumn3.DataPropertyName = "product_id";
            this.productidDataGridViewTextBoxColumn3.HeaderText = "product_id";
            this.productidDataGridViewTextBoxColumn3.Name = "productidDataGridViewTextBoxColumn3";
            // 
            // purchasesBindingSource
            // 
            this.purchasesBindingSource.DataMember = "Purchases";
            this.purchasesBindingSource.DataSource = this.практика_КудаевDataSetPurchases;
            // 
            // практика_КудаевDataSetPurchases
            // 
            this.практика_КудаевDataSetPurchases.DataSetName = "Практика_КудаевDataSetPurchases";
            this.практика_КудаевDataSetPurchases.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // SignOut
            // 
            this.SignOut.BackColor = System.Drawing.Color.White;
            this.SignOut.FlatAppearance.BorderSize = 0;
            this.SignOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SignOut.Font = new System.Drawing.Font("Arial", 11F);
            this.SignOut.Location = new System.Drawing.Point(801, 34);
            this.SignOut.Name = "SignOut";
            this.SignOut.Size = new System.Drawing.Size(75, 23);
            this.SignOut.TabIndex = 1;
            this.SignOut.Text = "Выйти";
            this.SignOut.UseVisualStyleBackColor = false;
            this.SignOut.Click += new System.EventHandler(this.button1_Click);
            // 
            // SettingsColor
            // 
            this.SettingsColor.BackColor = System.Drawing.Color.White;
            this.SettingsColor.FlatAppearance.BorderSize = 0;
            this.SettingsColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SettingsColor.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SettingsColor.Location = new System.Drawing.Point(801, 63);
            this.SettingsColor.Name = "SettingsColor";
            this.SettingsColor.Size = new System.Drawing.Size(75, 23);
            this.SettingsColor.TabIndex = 2;
            this.SettingsColor.Text = "Цвет";
            this.SettingsColor.UseVisualStyleBackColor = false;
            this.SettingsColor.Click += new System.EventHandler(this.SettingsColor_Click);
            // 
            // ordersTableAdapter
            // 
            this.ordersTableAdapter.ClearBeforeFill = true;
            // 
            // production_OperationsTableAdapter
            // 
            this.production_OperationsTableAdapter.ClearBeforeFill = true;
            // 
            // warehouse_StocksTableAdapter
            // 
            this.warehouse_StocksTableAdapter.ClearBeforeFill = true;
            // 
            // usersTableAdapter
            // 
            this.usersTableAdapter.ClearBeforeFill = true;
            // 
            // productsTableAdapter
            // 
            this.productsTableAdapter.ClearBeforeFill = true;
            // 
            // purchasesTableAdapter
            // 
            this.purchasesTableAdapter.ClearBeforeFill = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Red;
            this.panel3.Controls.Add(this.dateTimePicker1);
            this.panel3.Controls.Add(this.operation_resp);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.operation_id);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.operation_order_id);
            this.panel3.Controls.Add(this.operation_product_id);
            this.panel3.Controls.Add(this.operation_type);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label12);
            this.panel3.ForeColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(7, 163);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(206, 303);
            this.panel3.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(4, 1);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(21, 18);
            this.label6.TabIndex = 3;
            this.label6.Text = "id";
            // 
            // operation_id
            // 
            this.operation_id.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.operation_id.Location = new System.Drawing.Point(4, 22);
            this.operation_id.Name = "operation_id";
            this.operation_id.Size = new System.Drawing.Size(100, 26);
            this.operation_id.TabIndex = 5;
            this.operation_id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(4, 51);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 18);
            this.label7.TabIndex = 6;
            this.label7.Text = "id заказа";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(4, 201);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(123, 18);
            this.label8.TabIndex = 12;
            this.label8.Text = "Дата окончания";
            // 
            // operation_order_id
            // 
            this.operation_order_id.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.operation_order_id.Location = new System.Drawing.Point(4, 72);
            this.operation_order_id.Name = "operation_order_id";
            this.operation_order_id.Size = new System.Drawing.Size(100, 26);
            this.operation_order_id.TabIndex = 7;
            this.operation_order_id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // operation_product_id
            // 
            this.operation_product_id.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.operation_product_id.Location = new System.Drawing.Point(4, 122);
            this.operation_product_id.Name = "operation_product_id";
            this.operation_product_id.Size = new System.Drawing.Size(100, 26);
            this.operation_product_id.TabIndex = 9;
            this.operation_product_id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // operation_type
            // 
            this.operation_type.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.operation_type.Location = new System.Drawing.Point(4, 172);
            this.operation_type.Name = "operation_type";
            this.operation_type.Size = new System.Drawing.Size(100, 26);
            this.operation_type.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(4, 101);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(90, 18);
            this.label11.TabIndex = 8;
            this.label11.Text = "id продукта";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(4, 151);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(105, 18);
            this.label12.TabIndex = 10;
            this.label12.Text = "Тип операции";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(4, 251);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(195, 18);
            this.label13.TabIndex = 14;
            this.label13.Text = "Ответственный сотрудник";
            // 
            // operation_resp
            // 
            this.operation_resp.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.operation_resp.Location = new System.Drawing.Point(4, 272);
            this.operation_resp.Name = "operation_resp";
            this.operation_resp.Size = new System.Drawing.Size(100, 26);
            this.operation_resp.TabIndex = 15;
            this.operation_resp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // addOperations
            // 
            this.addOperations.BackColor = System.Drawing.Color.White;
            this.addOperations.FlatAppearance.BorderSize = 0;
            this.addOperations.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addOperations.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addOperations.Location = new System.Drawing.Point(219, 163);
            this.addOperations.Name = "addOperations";
            this.addOperations.Size = new System.Drawing.Size(113, 35);
            this.addOperations.TabIndex = 18;
            this.addOperations.Text = "Добавить";
            this.addOperations.UseVisualStyleBackColor = false;
            this.addOperations.Click += new System.EventHandler(this.addOperations_Click);
            // 
            // editOperations
            // 
            this.editOperations.BackColor = System.Drawing.Color.White;
            this.editOperations.FlatAppearance.BorderSize = 0;
            this.editOperations.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.editOperations.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.editOperations.Location = new System.Drawing.Point(338, 163);
            this.editOperations.Name = "editOperations";
            this.editOperations.Size = new System.Drawing.Size(113, 35);
            this.editOperations.TabIndex = 19;
            this.editOperations.Text = "Изменить";
            this.editOperations.UseVisualStyleBackColor = false;
            this.editOperations.Click += new System.EventHandler(this.editOperations_Click);
            // 
            // deleteOperations
            // 
            this.deleteOperations.BackColor = System.Drawing.Color.White;
            this.deleteOperations.FlatAppearance.BorderSize = 0;
            this.deleteOperations.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteOperations.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.deleteOperations.Location = new System.Drawing.Point(457, 163);
            this.deleteOperations.Name = "deleteOperations";
            this.deleteOperations.Size = new System.Drawing.Size(113, 35);
            this.deleteOperations.TabIndex = 20;
            this.deleteOperations.Text = "Удалить";
            this.deleteOperations.UseVisualStyleBackColor = false;
            this.deleteOperations.Click += new System.EventHandler(this.deleteOperations_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.ascOperations);
            this.groupBox3.Controls.Add(this.descOperations);
            this.groupBox3.Controls.Add(this.sortOperations);
            this.groupBox3.Controls.Add(this.comboBox2);
            this.groupBox3.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox3.Location = new System.Drawing.Point(219, 204);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(328, 262);
            this.groupBox3.TabIndex = 21;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Сортировка по";
            // 
            // ascOperations
            // 
            this.ascOperations.AutoSize = true;
            this.ascOperations.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ascOperations.Location = new System.Drawing.Point(6, 88);
            this.ascOperations.Name = "ascOperations";
            this.ascOperations.Size = new System.Drawing.Size(145, 22);
            this.ascOperations.TabIndex = 3;
            this.ascOperations.TabStop = true;
            this.ascOperations.Text = "По возрастанию";
            this.ascOperations.UseVisualStyleBackColor = true;
            // 
            // descOperations
            // 
            this.descOperations.AutoSize = true;
            this.descOperations.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.descOperations.Location = new System.Drawing.Point(6, 60);
            this.descOperations.Name = "descOperations";
            this.descOperations.Size = new System.Drawing.Size(124, 22);
            this.descOperations.TabIndex = 2;
            this.descOperations.TabStop = true;
            this.descOperations.Text = "По убыванию";
            this.descOperations.UseVisualStyleBackColor = true;
            this.descOperations.CheckedChanged += new System.EventHandler(this.descOperations_CheckedChanged);
            // 
            // sortOperations
            // 
            this.sortOperations.BackColor = System.Drawing.Color.White;
            this.sortOperations.FlatAppearance.BorderSize = 0;
            this.sortOperations.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sortOperations.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold);
            this.sortOperations.Location = new System.Drawing.Point(133, 28);
            this.sortOperations.Name = "sortOperations";
            this.sortOperations.Size = new System.Drawing.Size(31, 26);
            this.sortOperations.TabIndex = 1;
            this.sortOperations.Text = "L";
            this.sortOperations.UseVisualStyleBackColor = false;
            this.sortOperations.Click += new System.EventHandler(this.sortOperations_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "id",
            "id заказа",
            "id продукта",
            "Тип операции",
            "Дата окончания",
            "Ответственный сотрудник"});
            this.comboBox2.Location = new System.Drawing.Point(6, 28);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 26);
            this.comboBox2.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.find_id_operations);
            this.groupBox4.Controls.Add(this.findOperations);
            this.groupBox4.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox4.Location = new System.Drawing.Point(553, 204);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(209, 68);
            this.groupBox4.TabIndex = 22;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Поиск по id";
            // 
            // find_id_operations
            // 
            this.find_id_operations.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.find_id_operations.Location = new System.Drawing.Point(6, 28);
            this.find_id_operations.Name = "find_id_operations";
            this.find_id_operations.Size = new System.Drawing.Size(100, 26);
            this.find_id_operations.TabIndex = 16;
            this.find_id_operations.TextChanged += new System.EventHandler(this.find_id_operations_TextChanged);
            this.find_id_operations.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // findOperations
            // 
            this.findOperations.BackColor = System.Drawing.Color.White;
            this.findOperations.Enabled = false;
            this.findOperations.FlatAppearance.BorderSize = 0;
            this.findOperations.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.findOperations.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold);
            this.findOperations.Location = new System.Drawing.Point(112, 28);
            this.findOperations.Name = "findOperations";
            this.findOperations.Size = new System.Drawing.Size(31, 26);
            this.findOperations.TabIndex = 1;
            this.findOperations.Text = "L";
            this.findOperations.UseVisualStyleBackColor = false;
            this.findOperations.Click += new System.EventHandler(this.findOperations_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dateTimePicker1.Location = new System.Drawing.Point(4, 222);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(192, 26);
            this.dateTimePicker1.TabIndex = 16;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Red;
            this.panel4.Controls.Add(this.stocks_location);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.stocks_id);
            this.panel4.Controls.Add(this.stocks_product_id);
            this.panel4.Controls.Add(this.stocks_quantity);
            this.panel4.Controls.Add(this.label18);
            this.panel4.Controls.Add(this.label19);
            this.panel4.ForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(3, 159);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(115, 207);
            this.panel4.TabIndex = 18;
            // 
            // stocks_location
            // 
            this.stocks_location.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.stocks_location.Location = new System.Drawing.Point(4, 172);
            this.stocks_location.Name = "stocks_location";
            this.stocks_location.Size = new System.Drawing.Size(100, 26);
            this.stocks_location.TabIndex = 15;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(4, 151);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 18);
            this.label14.TabIndex = 14;
            this.label14.Text = "Адрес";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(4, 1);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(21, 18);
            this.label15.TabIndex = 3;
            this.label15.Text = "id";
            // 
            // stocks_id
            // 
            this.stocks_id.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.stocks_id.Location = new System.Drawing.Point(4, 22);
            this.stocks_id.Name = "stocks_id";
            this.stocks_id.Size = new System.Drawing.Size(100, 26);
            this.stocks_id.TabIndex = 5;
            this.stocks_id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // stocks_product_id
            // 
            this.stocks_product_id.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.stocks_product_id.Location = new System.Drawing.Point(4, 72);
            this.stocks_product_id.Name = "stocks_product_id";
            this.stocks_product_id.Size = new System.Drawing.Size(100, 26);
            this.stocks_product_id.TabIndex = 9;
            this.stocks_product_id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // stocks_quantity
            // 
            this.stocks_quantity.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.stocks_quantity.Location = new System.Drawing.Point(4, 122);
            this.stocks_quantity.Name = "stocks_quantity";
            this.stocks_quantity.Size = new System.Drawing.Size(100, 26);
            this.stocks_quantity.TabIndex = 11;
            this.stocks_quantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(4, 51);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(90, 18);
            this.label18.TabIndex = 8;
            this.label18.Text = "id продукта";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(4, 101);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(92, 18);
            this.label19.TabIndex = 10;
            this.label19.Text = "Количество";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.ascStocks);
            this.groupBox5.Controls.Add(this.descStocks);
            this.groupBox5.Controls.Add(this.sortStocks);
            this.groupBox5.Controls.Add(this.comboBox3);
            this.groupBox5.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox5.Location = new System.Drawing.Point(124, 200);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(328, 247);
            this.groupBox5.TabIndex = 19;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Сортировка по";
            // 
            // ascStocks
            // 
            this.ascStocks.AutoSize = true;
            this.ascStocks.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ascStocks.Location = new System.Drawing.Point(6, 88);
            this.ascStocks.Name = "ascStocks";
            this.ascStocks.Size = new System.Drawing.Size(145, 22);
            this.ascStocks.TabIndex = 3;
            this.ascStocks.TabStop = true;
            this.ascStocks.Text = "По возрастанию";
            this.ascStocks.UseVisualStyleBackColor = true;
            // 
            // descStocks
            // 
            this.descStocks.AutoSize = true;
            this.descStocks.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.descStocks.Location = new System.Drawing.Point(6, 60);
            this.descStocks.Name = "descStocks";
            this.descStocks.Size = new System.Drawing.Size(124, 22);
            this.descStocks.TabIndex = 2;
            this.descStocks.TabStop = true;
            this.descStocks.Text = "По убыванию";
            this.descStocks.UseVisualStyleBackColor = true;
            this.descStocks.CheckedChanged += new System.EventHandler(this.descStocks_CheckedChanged);
            // 
            // sortStocks
            // 
            this.sortStocks.BackColor = System.Drawing.Color.White;
            this.sortStocks.FlatAppearance.BorderSize = 0;
            this.sortStocks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sortStocks.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold);
            this.sortStocks.Location = new System.Drawing.Point(133, 28);
            this.sortStocks.Name = "sortStocks";
            this.sortStocks.Size = new System.Drawing.Size(31, 26);
            this.sortStocks.TabIndex = 1;
            this.sortStocks.Text = "L";
            this.sortStocks.UseVisualStyleBackColor = false;
            this.sortStocks.Click += new System.EventHandler(this.sortStocks_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "id",
            "id продукта",
            "Количество",
            "Адрес"});
            this.comboBox3.Location = new System.Drawing.Point(6, 28);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 26);
            this.comboBox3.TabIndex = 0;
            // 
            // addStocks
            // 
            this.addStocks.BackColor = System.Drawing.Color.White;
            this.addStocks.FlatAppearance.BorderSize = 0;
            this.addStocks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addStocks.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addStocks.Location = new System.Drawing.Point(124, 159);
            this.addStocks.Name = "addStocks";
            this.addStocks.Size = new System.Drawing.Size(113, 35);
            this.addStocks.TabIndex = 20;
            this.addStocks.Text = "Добавить";
            this.addStocks.UseVisualStyleBackColor = false;
            this.addStocks.Click += new System.EventHandler(this.addStocks_Click);
            // 
            // editStocks
            // 
            this.editStocks.BackColor = System.Drawing.Color.White;
            this.editStocks.FlatAppearance.BorderSize = 0;
            this.editStocks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.editStocks.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.editStocks.Location = new System.Drawing.Point(243, 159);
            this.editStocks.Name = "editStocks";
            this.editStocks.Size = new System.Drawing.Size(113, 35);
            this.editStocks.TabIndex = 21;
            this.editStocks.Text = "Изменить";
            this.editStocks.UseVisualStyleBackColor = false;
            this.editStocks.Click += new System.EventHandler(this.editStocks_Click);
            // 
            // deleteStocks
            // 
            this.deleteStocks.BackColor = System.Drawing.Color.White;
            this.deleteStocks.FlatAppearance.BorderSize = 0;
            this.deleteStocks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteStocks.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.deleteStocks.Location = new System.Drawing.Point(362, 159);
            this.deleteStocks.Name = "deleteStocks";
            this.deleteStocks.Size = new System.Drawing.Size(113, 35);
            this.deleteStocks.TabIndex = 22;
            this.deleteStocks.Text = "Удалить";
            this.deleteStocks.UseVisualStyleBackColor = false;
            this.deleteStocks.Click += new System.EventHandler(this.deleteStocks_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.find_id_stocks);
            this.groupBox6.Controls.Add(this.findStocks);
            this.groupBox6.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox6.Location = new System.Drawing.Point(458, 200);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(209, 68);
            this.groupBox6.TabIndex = 23;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Поиск по id";
            // 
            // find_id_stocks
            // 
            this.find_id_stocks.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.find_id_stocks.Location = new System.Drawing.Point(6, 28);
            this.find_id_stocks.Name = "find_id_stocks";
            this.find_id_stocks.Size = new System.Drawing.Size(100, 26);
            this.find_id_stocks.TabIndex = 16;
            this.find_id_stocks.TextChanged += new System.EventHandler(this.find_id_stocks_TextChanged);
            this.find_id_stocks.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // findStocks
            // 
            this.findStocks.BackColor = System.Drawing.Color.White;
            this.findStocks.Enabled = false;
            this.findStocks.FlatAppearance.BorderSize = 0;
            this.findStocks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.findStocks.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold);
            this.findStocks.Location = new System.Drawing.Point(112, 28);
            this.findStocks.Name = "findStocks";
            this.findStocks.Size = new System.Drawing.Size(31, 26);
            this.findStocks.TabIndex = 1;
            this.findStocks.Text = "L";
            this.findStocks.UseVisualStyleBackColor = false;
            this.findStocks.Click += new System.EventHandler(this.findStocks_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Red;
            this.panel5.Controls.Add(this.user_role);
            this.panel5.Controls.Add(this.user_password);
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.label17);
            this.panel5.Controls.Add(this.user_id);
            this.panel5.Controls.Add(this.user_login);
            this.panel5.Controls.Add(this.label20);
            this.panel5.Controls.Add(this.label21);
            this.panel5.ForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(3, 159);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(115, 207);
            this.panel5.TabIndex = 19;
            // 
            // user_password
            // 
            this.user_password.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.user_password.Location = new System.Drawing.Point(4, 172);
            this.user_password.Name = "user_password";
            this.user_password.Size = new System.Drawing.Size(100, 26);
            this.user_password.TabIndex = 15;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(4, 151);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(63, 18);
            this.label16.TabIndex = 14;
            this.label16.Text = "Пароль";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(4, 1);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(21, 18);
            this.label17.TabIndex = 3;
            this.label17.Text = "id";
            // 
            // user_id
            // 
            this.user_id.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.user_id.Location = new System.Drawing.Point(4, 22);
            this.user_id.Name = "user_id";
            this.user_id.Size = new System.Drawing.Size(100, 26);
            this.user_id.TabIndex = 5;
            this.user_id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.Location = new System.Drawing.Point(4, 51);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(44, 18);
            this.label20.TabIndex = 8;
            this.label20.Text = "Роль";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(4, 101);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(50, 18);
            this.label21.TabIndex = 10;
            this.label21.Text = "Логин";
            // 
            // user_login
            // 
            this.user_login.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.user_login.Location = new System.Drawing.Point(4, 122);
            this.user_login.Name = "user_login";
            this.user_login.Size = new System.Drawing.Size(100, 26);
            this.user_login.TabIndex = 11;
            // 
            // user_role
            // 
            this.user_role.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.user_role.FormattingEnabled = true;
            this.user_role.Items.AddRange(new object[] {
            "администратор",
            "сотрудник",
            "клиент"});
            this.user_role.Location = new System.Drawing.Point(4, 72);
            this.user_role.Name = "user_role";
            this.user_role.Size = new System.Drawing.Size(100, 26);
            this.user_role.TabIndex = 20;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.ascUsers);
            this.groupBox7.Controls.Add(this.descUsers);
            this.groupBox7.Controls.Add(this.sortUsers);
            this.groupBox7.Controls.Add(this.comboBox4);
            this.groupBox7.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox7.Location = new System.Drawing.Point(124, 200);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(328, 247);
            this.groupBox7.TabIndex = 20;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Сортировка по";
            // 
            // ascUsers
            // 
            this.ascUsers.AutoSize = true;
            this.ascUsers.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ascUsers.Location = new System.Drawing.Point(6, 88);
            this.ascUsers.Name = "ascUsers";
            this.ascUsers.Size = new System.Drawing.Size(145, 22);
            this.ascUsers.TabIndex = 3;
            this.ascUsers.TabStop = true;
            this.ascUsers.Text = "По возрастанию";
            this.ascUsers.UseVisualStyleBackColor = true;
            // 
            // descUsers
            // 
            this.descUsers.AutoSize = true;
            this.descUsers.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.descUsers.Location = new System.Drawing.Point(6, 60);
            this.descUsers.Name = "descUsers";
            this.descUsers.Size = new System.Drawing.Size(124, 22);
            this.descUsers.TabIndex = 2;
            this.descUsers.TabStop = true;
            this.descUsers.Text = "По убыванию";
            this.descUsers.UseVisualStyleBackColor = true;
            this.descUsers.CheckedChanged += new System.EventHandler(this.descUsers_CheckedChanged);
            // 
            // sortUsers
            // 
            this.sortUsers.BackColor = System.Drawing.Color.White;
            this.sortUsers.FlatAppearance.BorderSize = 0;
            this.sortUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sortUsers.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold);
            this.sortUsers.Location = new System.Drawing.Point(133, 28);
            this.sortUsers.Name = "sortUsers";
            this.sortUsers.Size = new System.Drawing.Size(31, 26);
            this.sortUsers.TabIndex = 1;
            this.sortUsers.Text = "L";
            this.sortUsers.UseVisualStyleBackColor = false;
            this.sortUsers.Click += new System.EventHandler(this.sortUsers_Click);
            // 
            // comboBox4
            // 
            this.comboBox4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "id",
            "Роль",
            "Логин",
            "Пароль"});
            this.comboBox4.Location = new System.Drawing.Point(6, 28);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 26);
            this.comboBox4.TabIndex = 0;
            // 
            // addUsers
            // 
            this.addUsers.BackColor = System.Drawing.Color.White;
            this.addUsers.FlatAppearance.BorderSize = 0;
            this.addUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addUsers.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addUsers.Location = new System.Drawing.Point(124, 159);
            this.addUsers.Name = "addUsers";
            this.addUsers.Size = new System.Drawing.Size(113, 35);
            this.addUsers.TabIndex = 21;
            this.addUsers.Text = "Добавить";
            this.addUsers.UseVisualStyleBackColor = false;
            this.addUsers.Click += new System.EventHandler(this.addUsers_Click);
            // 
            // editUsers
            // 
            this.editUsers.BackColor = System.Drawing.Color.White;
            this.editUsers.FlatAppearance.BorderSize = 0;
            this.editUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.editUsers.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.editUsers.Location = new System.Drawing.Point(243, 159);
            this.editUsers.Name = "editUsers";
            this.editUsers.Size = new System.Drawing.Size(113, 35);
            this.editUsers.TabIndex = 22;
            this.editUsers.Text = "Изменить";
            this.editUsers.UseVisualStyleBackColor = false;
            this.editUsers.Click += new System.EventHandler(this.editUsers_Click);
            // 
            // deleteUsers
            // 
            this.deleteUsers.BackColor = System.Drawing.Color.White;
            this.deleteUsers.FlatAppearance.BorderSize = 0;
            this.deleteUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteUsers.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.deleteUsers.Location = new System.Drawing.Point(362, 159);
            this.deleteUsers.Name = "deleteUsers";
            this.deleteUsers.Size = new System.Drawing.Size(113, 35);
            this.deleteUsers.TabIndex = 23;
            this.deleteUsers.Text = "Удалить";
            this.deleteUsers.UseVisualStyleBackColor = false;
            this.deleteUsers.Click += new System.EventHandler(this.deleteUsers_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.find_id_users);
            this.groupBox8.Controls.Add(this.findUsers);
            this.groupBox8.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox8.Location = new System.Drawing.Point(458, 200);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(209, 68);
            this.groupBox8.TabIndex = 24;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Поиск по id";
            // 
            // find_id_users
            // 
            this.find_id_users.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.find_id_users.Location = new System.Drawing.Point(6, 28);
            this.find_id_users.Name = "find_id_users";
            this.find_id_users.Size = new System.Drawing.Size(100, 26);
            this.find_id_users.TabIndex = 16;
            this.find_id_users.TextChanged += new System.EventHandler(this.find_id_users_TextChanged);
            this.find_id_users.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // findUsers
            // 
            this.findUsers.BackColor = System.Drawing.Color.White;
            this.findUsers.Enabled = false;
            this.findUsers.FlatAppearance.BorderSize = 0;
            this.findUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.findUsers.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold);
            this.findUsers.Location = new System.Drawing.Point(112, 28);
            this.findUsers.Name = "findUsers";
            this.findUsers.Size = new System.Drawing.Size(31, 26);
            this.findUsers.TabIndex = 1;
            this.findUsers.Text = "L";
            this.findUsers.UseVisualStyleBackColor = false;
            this.findUsers.Click += new System.EventHandler(this.findUsers_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Red;
            this.panel6.Controls.Add(this.product_name);
            this.panel6.Controls.Add(this.product_price);
            this.panel6.Controls.Add(this.label22);
            this.panel6.Controls.Add(this.label23);
            this.panel6.Controls.Add(this.product_id);
            this.panel6.Controls.Add(this.product_desc);
            this.panel6.Controls.Add(this.label24);
            this.panel6.Controls.Add(this.label25);
            this.panel6.ForeColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(3, 159);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(115, 207);
            this.panel6.TabIndex = 20;
            // 
            // product_price
            // 
            this.product_price.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.product_price.Location = new System.Drawing.Point(4, 172);
            this.product_price.Name = "product_price";
            this.product_price.Size = new System.Drawing.Size(100, 26);
            this.product_price.TabIndex = 15;
            this.product_price.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(4, 151);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(46, 18);
            this.label22.TabIndex = 14;
            this.label22.Text = "Цена";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.Location = new System.Drawing.Point(4, 1);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(21, 18);
            this.label23.TabIndex = 3;
            this.label23.Text = "id";
            // 
            // product_id
            // 
            this.product_id.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.product_id.Location = new System.Drawing.Point(4, 22);
            this.product_id.Name = "product_id";
            this.product_id.Size = new System.Drawing.Size(100, 26);
            this.product_id.TabIndex = 5;
            this.product_id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // product_desc
            // 
            this.product_desc.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.product_desc.Location = new System.Drawing.Point(4, 122);
            this.product_desc.Name = "product_desc";
            this.product_desc.Size = new System.Drawing.Size(100, 26);
            this.product_desc.TabIndex = 11;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.Location = new System.Drawing.Point(4, 51);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(78, 18);
            this.label24.TabIndex = 8;
            this.label24.Text = "Название";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label25.Location = new System.Drawing.Point(4, 101);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(78, 18);
            this.label25.TabIndex = 10;
            this.label25.Text = "Описание";
            // 
            // product_name
            // 
            this.product_name.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.product_name.Location = new System.Drawing.Point(4, 72);
            this.product_name.Name = "product_name";
            this.product_name.Size = new System.Drawing.Size(100, 26);
            this.product_name.TabIndex = 16;
            // 
            // addProducts
            // 
            this.addProducts.BackColor = System.Drawing.Color.White;
            this.addProducts.FlatAppearance.BorderSize = 0;
            this.addProducts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addProducts.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addProducts.Location = new System.Drawing.Point(124, 159);
            this.addProducts.Name = "addProducts";
            this.addProducts.Size = new System.Drawing.Size(113, 35);
            this.addProducts.TabIndex = 22;
            this.addProducts.Text = "Добавить";
            this.addProducts.UseVisualStyleBackColor = false;
            this.addProducts.Click += new System.EventHandler(this.addProducts_Click);
            // 
            // editProducts
            // 
            this.editProducts.BackColor = System.Drawing.Color.White;
            this.editProducts.FlatAppearance.BorderSize = 0;
            this.editProducts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.editProducts.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.editProducts.Location = new System.Drawing.Point(243, 159);
            this.editProducts.Name = "editProducts";
            this.editProducts.Size = new System.Drawing.Size(113, 35);
            this.editProducts.TabIndex = 23;
            this.editProducts.Text = "Изменить";
            this.editProducts.UseVisualStyleBackColor = false;
            this.editProducts.Click += new System.EventHandler(this.editProducts_Click);
            // 
            // deleteProducts
            // 
            this.deleteProducts.BackColor = System.Drawing.Color.White;
            this.deleteProducts.FlatAppearance.BorderSize = 0;
            this.deleteProducts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteProducts.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.deleteProducts.Location = new System.Drawing.Point(362, 159);
            this.deleteProducts.Name = "deleteProducts";
            this.deleteProducts.Size = new System.Drawing.Size(113, 35);
            this.deleteProducts.TabIndex = 24;
            this.deleteProducts.Text = "Удалить";
            this.deleteProducts.UseVisualStyleBackColor = false;
            this.deleteProducts.Click += new System.EventHandler(this.deleteProducts_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.ascProducts);
            this.groupBox9.Controls.Add(this.descProducts);
            this.groupBox9.Controls.Add(this.sortProducts);
            this.groupBox9.Controls.Add(this.comboBox5);
            this.groupBox9.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox9.Location = new System.Drawing.Point(124, 200);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(328, 247);
            this.groupBox9.TabIndex = 25;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Сортировка по";
            // 
            // ascProducts
            // 
            this.ascProducts.AutoSize = true;
            this.ascProducts.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ascProducts.Location = new System.Drawing.Point(6, 88);
            this.ascProducts.Name = "ascProducts";
            this.ascProducts.Size = new System.Drawing.Size(145, 22);
            this.ascProducts.TabIndex = 3;
            this.ascProducts.TabStop = true;
            this.ascProducts.Text = "По возрастанию";
            this.ascProducts.UseVisualStyleBackColor = true;
            // 
            // descProducts
            // 
            this.descProducts.AutoSize = true;
            this.descProducts.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.descProducts.Location = new System.Drawing.Point(6, 60);
            this.descProducts.Name = "descProducts";
            this.descProducts.Size = new System.Drawing.Size(124, 22);
            this.descProducts.TabIndex = 2;
            this.descProducts.TabStop = true;
            this.descProducts.Text = "По убыванию";
            this.descProducts.UseVisualStyleBackColor = true;
            this.descProducts.CheckedChanged += new System.EventHandler(this.descProducts_CheckedChanged);
            // 
            // sortProducts
            // 
            this.sortProducts.BackColor = System.Drawing.Color.White;
            this.sortProducts.FlatAppearance.BorderSize = 0;
            this.sortProducts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sortProducts.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold);
            this.sortProducts.Location = new System.Drawing.Point(133, 28);
            this.sortProducts.Name = "sortProducts";
            this.sortProducts.Size = new System.Drawing.Size(31, 26);
            this.sortProducts.TabIndex = 1;
            this.sortProducts.Text = "L";
            this.sortProducts.UseVisualStyleBackColor = false;
            this.sortProducts.Click += new System.EventHandler(this.sortProducts_Click);
            // 
            // comboBox5
            // 
            this.comboBox5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "id",
            "Название",
            "Описание",
            "Цена"});
            this.comboBox5.Location = new System.Drawing.Point(6, 28);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(121, 26);
            this.comboBox5.TabIndex = 0;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.find_id_products);
            this.groupBox10.Controls.Add(this.findProducts);
            this.groupBox10.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox10.Location = new System.Drawing.Point(458, 200);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(209, 68);
            this.groupBox10.TabIndex = 26;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Поиск по id";
            // 
            // find_id_products
            // 
            this.find_id_products.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.find_id_products.Location = new System.Drawing.Point(6, 28);
            this.find_id_products.Name = "find_id_products";
            this.find_id_products.Size = new System.Drawing.Size(100, 26);
            this.find_id_products.TabIndex = 16;
            this.find_id_products.TextChanged += new System.EventHandler(this.find_id_products_TextChanged);
            this.find_id_products.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // findProducts
            // 
            this.findProducts.BackColor = System.Drawing.Color.White;
            this.findProducts.Enabled = false;
            this.findProducts.FlatAppearance.BorderSize = 0;
            this.findProducts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.findProducts.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold);
            this.findProducts.Location = new System.Drawing.Point(112, 28);
            this.findProducts.Name = "findProducts";
            this.findProducts.Size = new System.Drawing.Size(31, 26);
            this.findProducts.TabIndex = 1;
            this.findProducts.Text = "L";
            this.findProducts.UseVisualStyleBackColor = false;
            this.findProducts.Click += new System.EventHandler(this.findProducts_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Red;
            this.panel7.Controls.Add(this.dateTimePicker3);
            this.panel7.Controls.Add(this.dateTimePicker2);
            this.panel7.Controls.Add(this.purchase_total);
            this.panel7.Controls.Add(this.purchase_product_id);
            this.panel7.Controls.Add(this.label26);
            this.panel7.Controls.Add(this.label27);
            this.panel7.Controls.Add(this.purchase_id);
            this.panel7.Controls.Add(this.label28);
            this.panel7.Controls.Add(this.label29);
            this.panel7.Controls.Add(this.purchase_sup);
            this.panel7.Controls.Add(this.label30);
            this.panel7.Controls.Add(this.label31);
            this.panel7.ForeColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(3, 159);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(206, 303);
            this.panel7.TabIndex = 18;
            // 
            // purchase_product_id
            // 
            this.purchase_product_id.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.purchase_product_id.Location = new System.Drawing.Point(4, 272);
            this.purchase_product_id.Name = "purchase_product_id";
            this.purchase_product_id.Size = new System.Drawing.Size(100, 26);
            this.purchase_product_id.TabIndex = 15;
            this.purchase_product_id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label26.Location = new System.Drawing.Point(4, 251);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(90, 18);
            this.label26.TabIndex = 14;
            this.label26.Text = "id продукта";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label27.Location = new System.Drawing.Point(4, 1);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(21, 18);
            this.label27.TabIndex = 3;
            this.label27.Text = "id";
            // 
            // purchase_id
            // 
            this.purchase_id.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.purchase_id.Location = new System.Drawing.Point(4, 22);
            this.purchase_id.Name = "purchase_id";
            this.purchase_id.Size = new System.Drawing.Size(100, 26);
            this.purchase_id.TabIndex = 5;
            this.purchase_id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label28.Location = new System.Drawing.Point(4, 51);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(102, 18);
            this.label28.TabIndex = 6;
            this.label28.Text = "Дата покупки";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label29.Location = new System.Drawing.Point(4, 201);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(134, 18);
            this.label29.TabIndex = 12;
            this.label29.Text = "Всего предметов";
            // 
            // purchase_sup
            // 
            this.purchase_sup.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.purchase_sup.Location = new System.Drawing.Point(4, 172);
            this.purchase_sup.Name = "purchase_sup";
            this.purchase_sup.Size = new System.Drawing.Size(100, 26);
            this.purchase_sup.TabIndex = 11;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label30.Location = new System.Drawing.Point(4, 101);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(158, 18);
            this.label30.TabIndex = 8;
            this.label30.Text = "Стоимость доставки";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label31.Location = new System.Drawing.Point(4, 151);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(87, 18);
            this.label31.TabIndex = 10;
            this.label31.Text = "Поставщик";
            // 
            // addPurchases
            // 
            this.addPurchases.BackColor = System.Drawing.Color.White;
            this.addPurchases.FlatAppearance.BorderSize = 0;
            this.addPurchases.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addPurchases.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addPurchases.Location = new System.Drawing.Point(215, 159);
            this.addPurchases.Name = "addPurchases";
            this.addPurchases.Size = new System.Drawing.Size(113, 35);
            this.addPurchases.TabIndex = 19;
            this.addPurchases.Text = "Добавить";
            this.addPurchases.UseVisualStyleBackColor = false;
            this.addPurchases.Click += new System.EventHandler(this.addPurchases_Click);
            // 
            // editPurchases
            // 
            this.editPurchases.BackColor = System.Drawing.Color.White;
            this.editPurchases.FlatAppearance.BorderSize = 0;
            this.editPurchases.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.editPurchases.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.editPurchases.Location = new System.Drawing.Point(334, 159);
            this.editPurchases.Name = "editPurchases";
            this.editPurchases.Size = new System.Drawing.Size(113, 35);
            this.editPurchases.TabIndex = 20;
            this.editPurchases.Text = "Изменить";
            this.editPurchases.UseVisualStyleBackColor = false;
            this.editPurchases.Click += new System.EventHandler(this.editPurchases_Click);
            // 
            // deletePurchases
            // 
            this.deletePurchases.BackColor = System.Drawing.Color.White;
            this.deletePurchases.FlatAppearance.BorderSize = 0;
            this.deletePurchases.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deletePurchases.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.deletePurchases.Location = new System.Drawing.Point(453, 159);
            this.deletePurchases.Name = "deletePurchases";
            this.deletePurchases.Size = new System.Drawing.Size(113, 35);
            this.deletePurchases.TabIndex = 21;
            this.deletePurchases.Text = "Удалить";
            this.deletePurchases.UseVisualStyleBackColor = false;
            this.deletePurchases.Click += new System.EventHandler(this.deletePurchases_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.ascPurchases);
            this.groupBox11.Controls.Add(this.descPurchases);
            this.groupBox11.Controls.Add(this.sortPurchases);
            this.groupBox11.Controls.Add(this.comboBox6);
            this.groupBox11.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox11.Location = new System.Drawing.Point(215, 200);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(328, 262);
            this.groupBox11.TabIndex = 22;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Сортировка по";
            // 
            // ascPurchases
            // 
            this.ascPurchases.AutoSize = true;
            this.ascPurchases.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ascPurchases.Location = new System.Drawing.Point(6, 88);
            this.ascPurchases.Name = "ascPurchases";
            this.ascPurchases.Size = new System.Drawing.Size(145, 22);
            this.ascPurchases.TabIndex = 3;
            this.ascPurchases.TabStop = true;
            this.ascPurchases.Text = "По возрастанию";
            this.ascPurchases.UseVisualStyleBackColor = true;
            // 
            // descPurchases
            // 
            this.descPurchases.AutoSize = true;
            this.descPurchases.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.descPurchases.Location = new System.Drawing.Point(6, 60);
            this.descPurchases.Name = "descPurchases";
            this.descPurchases.Size = new System.Drawing.Size(124, 22);
            this.descPurchases.TabIndex = 2;
            this.descPurchases.TabStop = true;
            this.descPurchases.Text = "По убыванию";
            this.descPurchases.UseVisualStyleBackColor = true;
            this.descPurchases.CheckedChanged += new System.EventHandler(this.descPurchases_CheckedChanged);
            // 
            // sortPurchases
            // 
            this.sortPurchases.BackColor = System.Drawing.Color.White;
            this.sortPurchases.FlatAppearance.BorderSize = 0;
            this.sortPurchases.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sortPurchases.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold);
            this.sortPurchases.Location = new System.Drawing.Point(133, 28);
            this.sortPurchases.Name = "sortPurchases";
            this.sortPurchases.Size = new System.Drawing.Size(31, 26);
            this.sortPurchases.TabIndex = 1;
            this.sortPurchases.Text = "L";
            this.sortPurchases.UseVisualStyleBackColor = false;
            this.sortPurchases.Click += new System.EventHandler(this.sortPurchases_Click);
            // 
            // comboBox6
            // 
            this.comboBox6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "id",
            "Дата покупки",
            "Дата доставки",
            "Поставщик",
            "Вся стоимость",
            "Всего предметов",
            "id продукта"});
            this.comboBox6.Location = new System.Drawing.Point(6, 28);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(121, 26);
            this.comboBox6.TabIndex = 0;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.find_id_purchases);
            this.groupBox12.Controls.Add(this.findPurchases);
            this.groupBox12.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox12.Location = new System.Drawing.Point(549, 200);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(209, 68);
            this.groupBox12.TabIndex = 23;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Поиск по id";
            // 
            // find_id_purchases
            // 
            this.find_id_purchases.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.find_id_purchases.Location = new System.Drawing.Point(6, 28);
            this.find_id_purchases.Name = "find_id_purchases";
            this.find_id_purchases.Size = new System.Drawing.Size(100, 26);
            this.find_id_purchases.TabIndex = 16;
            this.find_id_purchases.TextChanged += new System.EventHandler(this.find_id_purchases_TextChanged);
            this.find_id_purchases.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // findPurchases
            // 
            this.findPurchases.BackColor = System.Drawing.Color.White;
            this.findPurchases.Enabled = false;
            this.findPurchases.FlatAppearance.BorderSize = 0;
            this.findPurchases.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.findPurchases.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold);
            this.findPurchases.Location = new System.Drawing.Point(112, 28);
            this.findPurchases.Name = "findPurchases";
            this.findPurchases.Size = new System.Drawing.Size(31, 26);
            this.findPurchases.TabIndex = 1;
            this.findPurchases.Text = "L";
            this.findPurchases.UseVisualStyleBackColor = false;
            this.findPurchases.Click += new System.EventHandler(this.findPurchases_Click);
            // 
            // purchase_total
            // 
            this.purchase_total.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.purchase_total.Location = new System.Drawing.Point(4, 222);
            this.purchase_total.Name = "purchase_total";
            this.purchase_total.Size = new System.Drawing.Size(100, 26);
            this.purchase_total.TabIndex = 16;
            this.purchase_total.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.product_client_id_KeyPress);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CalendarFont = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dateTimePicker2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dateTimePicker2.Location = new System.Drawing.Point(4, 72);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(199, 26);
            this.dateTimePicker2.TabIndex = 17;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.CalendarFont = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dateTimePicker3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dateTimePicker3.Location = new System.Drawing.Point(4, 122);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(199, 26);
            this.dateTimePicker3.TabIndex = 18;
            // 
            // SettingsStyle
            // 
            this.SettingsStyle.BackColor = System.Drawing.Color.White;
            this.SettingsStyle.FlatAppearance.BorderSize = 0;
            this.SettingsStyle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SettingsStyle.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SettingsStyle.Location = new System.Drawing.Point(801, 92);
            this.SettingsStyle.Name = "SettingsStyle";
            this.SettingsStyle.Size = new System.Drawing.Size(75, 73);
            this.SettingsStyle.TabIndex = 3;
            this.SettingsStyle.Text = "Шрифт для полей";
            this.SettingsStyle.UseVisualStyleBackColor = false;
            this.SettingsStyle.Click += new System.EventHandler(this.SettingsStyle_Click);
            // 
            // SettingsStyleButtons
            // 
            this.SettingsStyleButtons.BackColor = System.Drawing.Color.White;
            this.SettingsStyleButtons.FlatAppearance.BorderSize = 0;
            this.SettingsStyleButtons.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SettingsStyleButtons.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SettingsStyleButtons.Location = new System.Drawing.Point(801, 171);
            this.SettingsStyleButtons.Name = "SettingsStyleButtons";
            this.SettingsStyleButtons.Size = new System.Drawing.Size(75, 73);
            this.SettingsStyleButtons.TabIndex = 4;
            this.SettingsStyleButtons.Text = "Шрифт для кнопок";
            this.SettingsStyleButtons.UseVisualStyleBackColor = false;
            this.SettingsStyleButtons.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Red;
            this.ClientSize = new System.Drawing.Size(888, 516);
            this.Controls.Add(this.SettingsStyleButtons);
            this.Controls.Add(this.SettingsStyle);
            this.Controls.Add(this.SettingsColor);
            this.Controls.Add(this.SignOut);
            this.Controls.Add(this.tabControl1);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.практика_КудаевDataSetOrders)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productionOperationsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.практика_КудаевDataSetProduction_Operations)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.warehouseStocksBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.практика_КудаевDataSetWarehouse_Stocks)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.практика_КудаевDataSetUsers1)).EndInit();
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.практика_КудаевDataSetProducts)).EndInit();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.purchasesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.практика_КудаевDataSetPurchases)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button SignOut;
        private System.Windows.Forms.Button SettingsColor;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Практика_КудаевDataSetOrders практика_КудаевDataSetOrders;
        private System.Windows.Forms.BindingSource ordersBindingSource;
        private Практика_КудаевDataSetOrdersTableAdapters.OrdersTableAdapter ordersTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView2;
        private Практика_КудаевDataSetProduction_Operations практика_КудаевDataSetProduction_Operations;
        private System.Windows.Forms.BindingSource productionOperationsBindingSource;
        private Практика_КудаевDataSetProduction_OperationsTableAdapters.Production_OperationsTableAdapter production_OperationsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productidDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn operationtypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn enddateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn responsibleemployeeidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView3;
        private Практика_КудаевDataSetWarehouse_Stocks практика_КудаевDataSetWarehouse_Stocks;
        private System.Windows.Forms.BindingSource warehouseStocksBindingSource;
        private Практика_КудаевDataSetWarehouse_StocksTableAdapters.Warehouse_StocksTableAdapter warehouse_StocksTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn productidDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn locationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView4;
        private Практика_КудаевDataSetUsers1 практика_КудаевDataSetUsers1;
        private System.Windows.Forms.BindingSource usersBindingSource;
        private Практика_КудаевDataSetUsers1TableAdapters.UsersTableAdapter usersTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn roleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn loginDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passwordDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView5;
        private Практика_КудаевDataSetProducts практика_КудаевDataSetProducts;
        private System.Windows.Forms.BindingSource productsBindingSource;
        private Практика_КудаевDataSetProductsTableAdapters.ProductsTableAdapter productsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView6;
        private Практика_КудаевDataSetPurchases практика_КудаевDataSetPurchases;
        private System.Windows.Forms.BindingSource purchasesBindingSource;
        private Практика_КудаевDataSetPurchasesTableAdapters.PurchasesTableAdapter purchasesTableAdapter;
        private System.Windows.Forms.Button editOrders;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchasedateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchasedeliveryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplierDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalcostDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalitemsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productidDataGridViewTextBoxColumn3;
        private System.Windows.Forms.TextBox order_id;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button deleteOrders;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox order_status;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox order_quantity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox order_product_id;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox order_client_id;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button sortOrders;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.RadioButton ascOrders;
        private System.Windows.Forms.RadioButton descOrders;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox find_id_orders;
        private System.Windows.Forms.Button findOrders;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox product_client_id;
        private System.Windows.Forms.TextBox quantity_client;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button addOrders;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox operation_resp;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox operation_id;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox operation_order_id;
        private System.Windows.Forms.TextBox operation_product_id;
        private System.Windows.Forms.TextBox operation_type;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button deleteOperations;
        private System.Windows.Forms.Button editOperations;
        private System.Windows.Forms.Button addOperations;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox find_id_operations;
        private System.Windows.Forms.Button findOperations;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton ascOperations;
        private System.Windows.Forms.RadioButton descOperations;
        private System.Windows.Forms.Button sortOperations;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox stocks_location;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox stocks_id;
        private System.Windows.Forms.TextBox stocks_product_id;
        private System.Windows.Forms.TextBox stocks_quantity;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button addStocks;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton ascStocks;
        private System.Windows.Forms.RadioButton descStocks;
        private System.Windows.Forms.Button sortStocks;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox find_id_stocks;
        private System.Windows.Forms.Button findStocks;
        private System.Windows.Forms.Button deleteStocks;
        private System.Windows.Forms.Button editStocks;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton ascUsers;
        private System.Windows.Forms.RadioButton descUsers;
        private System.Windows.Forms.Button sortUsers;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.ComboBox user_role;
        private System.Windows.Forms.TextBox user_password;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox user_id;
        private System.Windows.Forms.TextBox user_login;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button deleteUsers;
        private System.Windows.Forms.Button editUsers;
        private System.Windows.Forms.Button addUsers;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox find_id_users;
        private System.Windows.Forms.Button findUsers;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox find_id_products;
        private System.Windows.Forms.Button findProducts;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.RadioButton ascProducts;
        private System.Windows.Forms.RadioButton descProducts;
        private System.Windows.Forms.Button sortProducts;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Button deleteProducts;
        private System.Windows.Forms.Button editProducts;
        private System.Windows.Forms.Button addProducts;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox product_name;
        private System.Windows.Forms.TextBox product_price;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox product_id;
        private System.Windows.Forms.TextBox product_desc;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox purchase_product_id;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox purchase_id;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox purchase_sup;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox find_id_purchases;
        private System.Windows.Forms.Button findPurchases;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.RadioButton ascPurchases;
        private System.Windows.Forms.RadioButton descPurchases;
        private System.Windows.Forms.Button sortPurchases;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Button deletePurchases;
        private System.Windows.Forms.Button editPurchases;
        private System.Windows.Forms.Button addPurchases;
        private System.Windows.Forms.TextBox purchase_total;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.Button SettingsStyle;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.Button SettingsStyleButtons;
        private System.Windows.Forms.FontDialog fontDialog2;
    }
}