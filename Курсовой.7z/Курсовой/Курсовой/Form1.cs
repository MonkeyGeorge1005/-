﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Курсовой
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.KeyPreview = true;
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            this.button2.Click += new System.EventHandler(this.button2_Click);
        }

        public bool Admin;
        public bool ADMIN
        {
            get { return Admin; }
            set { value = Admin; }
        }
        public bool Employee;
        public bool EMPLOYEE
        { 
            get { return Employee; }
            set { value = Employee; }
        }
        public int index;
        public int INDEX
        {
            get { return index; }
            set {  index = value; }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "практика_КудаевDataSetUsers.Users". При необходимости она может быть перемещена или удалена.
            this.usersTableAdapter.Fill(this.практика_КудаевDataSetUsers.Users);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button3.Enabled = false;
            button3.Visible = true;
            button2.Visible = false;
            button1.Visible = false;
            button4.Visible = true;
            label1.Text = "Регистрация";
            textBox1.Clear();
            textBox2.Clear();
        }

        public void Create(string log, string pass)
        {
            this.usersTableAdapter.Fill(this.практика_КудаевDataSetUsers.Users);
            try
            {
                log = textBox1.Text;
                pass = textBox2.Text;
                string role = "клиент";
                string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDell = "SELECT COUNT(*) FROM [Users] where [login] = @log";
                SqlCommand cmd2 = new SqlCommand(ComDell, MyConnection);
                cmd2.Parameters.AddWithValue("@log", log);
                MyConnection.Open();
                int result = 0;
                result = (int)cmd2.ExecuteScalar();
                if (result == 0 && log != "")
                {
                    string ComDel = $"Insert into Users([login],[role],[password]) VALUES(@login,@role,@password);";
                    SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                    cmd1.Parameters.AddWithValue("@login", log);
                    cmd1.Parameters.AddWithValue("@role", role);
                    cmd1.Parameters.AddWithValue("@password", pass);
                    cmd1.ExecuteNonQuery();
                }
                else
                {
                    MessageBox.Show("Такой логин уже занят, выберите другое имя пользователя");
                }
                MyConnection.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            button1.Enabled = false;
            button3.Enabled = false;
            button3.Visible = false;
            button2.Visible = true;
            button1.Visible = true;
            button4.Visible = false;
            label1.Text = "Авторизация";
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string log = textBox1.Text;
                string pass = textBox2.Text;
                Create(log, pass);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button3.Enabled = false;
            button3.Visible = false;
            button2.Visible = true;
            button1.Visible = true;
            button4.Visible = false;
            label1.Text = "Авторизация";
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button5_MouseUp(object sender, MouseEventArgs e)
        {
            button4.ForeColor = Color.Gray;
            textBox2.PasswordChar = '*';
        }

        private void button5_MouseDown(object sender, MouseEventArgs e)
        {
            button4.ForeColor = Color.White;
            textBox2.PasswordChar = '\0';
        }

        public void Check(string log, string pass)
        {
            this.usersTableAdapter.Fill(this.практика_КудаевDataSetUsers.Users);
            try
            {
                log = textBox1.Text;
                pass = textBox2.Text;
                int j = 0;
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    if (dataGridView1.Rows[i].Cells[2].Value.ToString() == log && dataGridView1.Rows[i].Cells[3].Value.ToString() == pass)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                {
                    throw new Exception("Неправильный логин или пароль!");
                }
                string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDel = "Select login from Users where login = @log";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                cmd1.Parameters.AddWithValue("@log", log);
                string ComDell = "Select password from Users where password = @pass and login = @log";
                SqlCommand cmd2 = new SqlCommand(ComDell, MyConnection);
                cmd2.Parameters.AddWithValue("@log", log);
                cmd2.Parameters.AddWithValue("@pass", pass);
                string ComDelll = "Select role from Users where password = @pass and login = @log";
                SqlCommand cmd3 = new SqlCommand(ComDelll, MyConnection);
                cmd3.Parameters.AddWithValue("@log", log);
                cmd3.Parameters.AddWithValue("@pass", pass);
                MyConnection.Open();
                string a = cmd1.ExecuteScalar().ToString().TrimEnd();
                string b = cmd2.ExecuteScalar().ToString().TrimEnd();
                string c = cmd3.ExecuteScalar().ToString().TrimEnd();
                if (a == log && b == pass)
                {
                    MainForm form = new MainForm();  // создание экземпляра первой формы
                    if (c == "администратор")
                    {
                        Admin = true;
                        Employee = false;
                    }
                    else if (c == "сотрудник")
                    {
                        Admin = false;
                        Employee = true;
                    }
                    else
                    {
                        Admin = false;
                        Employee = false;
                    }
                    string commandForIndex = "Select id from Users where password = @pass and login = @log";
                    SqlCommand cmdForIndex = new SqlCommand(commandForIndex, MyConnection);
                    cmdForIndex.Parameters.AddWithValue("@log", log);
                    cmdForIndex.Parameters.AddWithValue("@pass", pass);
                    string id = cmdForIndex.ExecuteScalar().ToString().TrimEnd();
                    INDEX = Convert.ToInt32(id);
                    form.Owner = this;
                    form.ShowDialog();
                    this.Visible = false;
                    this.Enabled = false;
                }
                MyConnection.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string log = textBox1.Text;
            string pass = textBox2.Text;
            try
            {
                Check(log, pass);
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && button1.Visible == true && button3.Visible == false)
                button1.PerformClick();
            else if (e.KeyCode == Keys.Enter && button3.Visible == true && button1.Visible == false)
                button3.PerformClick();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != string.Empty && textBox2.Text != string.Empty)
            {
                button1.Enabled = true;
                button3.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
                button3.Enabled = false;
            }
        }
    }
}
