﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.XPath;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Курсовой
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        Form1 form1;
        public bool a = false;
        public bool em = false;
        private void MainForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "практика_КудаевDataSetPurchases.Purchases". При необходимости она может быть перемещена или удалена.
            this.purchasesTableAdapter.Fill(this.практика_КудаевDataSetPurchases.Purchases);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "практика_КудаевDataSetProducts.Products". При необходимости она может быть перемещена или удалена.
            this.productsTableAdapter.Fill(this.практика_КудаевDataSetProducts.Products);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "практика_КудаевDataSetUsers1.Users". При необходимости она может быть перемещена или удалена.
            this.usersTableAdapter.Fill(this.практика_КудаевDataSetUsers1.Users);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "практика_КудаевDataSetWarehouse_Stocks.Warehouse_Stocks". При необходимости она может быть перемещена или удалена.
            this.warehouse_StocksTableAdapter.Fill(this.практика_КудаевDataSetWarehouse_Stocks.Warehouse_Stocks);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "практика_КудаевDataSetProduction_Operations.Production_Operations". При необходимости она может быть перемещена или удалена.
            this.production_OperationsTableAdapter.Fill(this.практика_КудаевDataSetProduction_Operations.Production_Operations);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "практика_КудаевDataSetOrders.Orders". При необходимости она может быть перемещена или удалена.
            this.ordersTableAdapter.Fill(this.практика_КудаевDataSetOrders.Orders);
            form1 = (Form1)this.Owner;
            form1.Hide();
            a = form1.ADMIN;
            em = form1.EMPLOYEE;
            if (a)
            {
                panel1.Visible = true;
                panel2.Visible = false;
                addOrders.Visible = false;
            }
            else if (em)
            {
                tabControl1.TabPages.Remove(tabPage4);
                tabControl1.TabPages.Remove(tabPage6);
                panel1.Visible = true;
                panel2.Visible = false;
                addOrders.Visible = false;
                SettingsColor.Visible = false;
                SettingsStyle.Visible = false;
                SettingsStyleButtons.Visible = false;
            }
            else
            {
                dataGridView1.Visible = false;
                editOrders.Visible = false;
                deleteOrders.Visible = false;
                panel1.Visible = false;
                groupBox1.Visible = false;
                groupBox2.Visible = false;
                panel2.Visible = true;
                tabPage1.Size = new Size(200, 200);
                tabControl1.Size = new Size(200, 200);
                this.Size = new Size(320, 320);
                SettingsColor.Visible = false;
                SettingsStyle.Visible = false;
                SettingsStyleButtons.Visible = false;
                SignOut.Location = new Point(220, 64);
                tabControl1.TabPages.Remove(tabPage2);
                tabControl1.TabPages.Remove(tabPage3);
                tabControl1.TabPages.Remove(tabPage4);
                tabControl1.TabPages.Remove(tabPage6);
                panel6.Visible = false;
                addProducts.Visible = false;
                editProducts.Visible = false;
                deleteProducts.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            a = false;
            em = false;
            this.Hide();
            Form1 form = new Form1();
            form.ShowDialog();
            this.Show();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            form1 = null;
            Application.Exit();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!a && !em)
            {
                TabPage selectedTabPage = tabControl1.SelectedTab;
                switch (selectedTabPage.Name)
                {
                    case "tabPage1":
                        tabPage1.Size = new Size(200, 200);
                        tabControl1.Size = new Size(200, 200);
                        this.Size = new Size(320, 320);
                        SettingsColor.Visible = false;
                        SignOut.Location = new Point(220, 64);
                        break;
                    case "tabPage5":
                        tabPage5.Size = new Size(768, 461);
                        tabControl1.Size = new Size(776, 487);
                        this.Size = new Size(904, 550);
                        SignOut.Location = new Point(801, 34);
                        break;
                }
            }
        }

        private void product_client_id_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (int)Keys.Back)
                e.Handled = true;
        }

        private void addOrders_Click(object sender, EventArgs e) //ПЕРВАЯ ТАБЛИЦА
        {
            string productID = product_client_id.Text;
            string quantity = quantity_client.Text;
            string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Insert into Orders([client_id], [product_id], [quantity], [status]) VALUES(@id, @product_id, @quan, @status);";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@id", form1.INDEX);
            cmd1.Parameters.AddWithValue("@product_id", productID);
            cmd1.Parameters.AddWithValue("@quan", quantity);
            cmd1.Parameters.AddWithValue("@status", "новый");
            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();
            this.ordersTableAdapter.Fill(this.практика_КудаевDataSetOrders.Orders);
            order_id.Clear();
            order_client_id.Clear();
            order_product_id.Clear();
            order_quantity.Clear();
            order_status.Clear();
        }

        private void editOrders_Click(object sender, EventArgs e)
        {
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    if (dataGridView1.Rows[i].Cells[0].Value.ToString() == order_id.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Заказ не найден!");
                string orderId = order_id.Text;
                string clientID = order_client_id.Text;
                string productID = order_product_id.Text;
                string quantity = order_client_id.Text;
                string status = order_status.Text;
                string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDel = $"Update Orders set [client_id] = @client_id, [product_id] = @product_id, [quantity] = @quan, [status] = @status where [id] = @id;";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                cmd1.Parameters.AddWithValue("@id", orderId);
                cmd1.Parameters.AddWithValue("@client_id", clientID);
                cmd1.Parameters.AddWithValue("@product_id", productID);
                cmd1.Parameters.AddWithValue("@quan", quantity);
                cmd1.Parameters.AddWithValue("@status", status);
                MyConnection.Open();
                cmd1.ExecuteNonQuery();
                MyConnection.Close();
                this.ordersTableAdapter.Fill(this.практика_КудаевDataSetOrders.Orders);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            order_id.Clear();
            order_client_id.Clear();
            order_product_id.Clear();
            order_quantity.Clear();
            order_status.Clear();
        }

        private void deleteOrders_Click(object sender, EventArgs e)
        {
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    if (dataGridView1.Rows[i].Cells[0].Value.ToString() == order_id.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Игрок не найден!");
                string id = order_id.Text;
                string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDel = "Delete from Orders where [id] = @id";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                cmd1.Parameters.AddWithValue("@id", id);
                MyConnection.Open();
                cmd1.ExecuteNonQuery();
                MyConnection.Close();
                this.ordersTableAdapter.Fill(this.практика_КудаевDataSetOrders.Orders);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            order_id.Clear();
            order_client_id.Clear();
            order_product_id.Clear();
            order_quantity.Clear();
            order_status.Clear();
        }
        private void findOrders_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            string searchValue = find_id_orders.Text;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    if (dataGridView1.Rows[i].Cells[0].Value.ToString() == find_id_orders.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Заказ не найден!");
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Cells[0].Value.ToString().TrimEnd() == searchValue)
                    {
                        row.Selected = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            dataGridView1.Refresh();
            find_id_orders.Clear();
            findOrders.Enabled = false;
        }

        private void sortOrders_Click(object sender, EventArgs e)
        {
            if (descOrders.Checked)
            {
                switch (comboBox1.Text)
                {
                    case "id":
                        dataGridView1.Sort(dataGridView1.Columns[0], ListSortDirection.Descending);
                        break;
                    case "id клиента":
                        dataGridView1.Sort(dataGridView1.Columns[1], ListSortDirection.Descending);
                        break;
                    case "id продукта":
                        dataGridView1.Sort(dataGridView1.Columns[2], ListSortDirection.Descending);
                        break;
                    case "Количество":
                        dataGridView1.Sort(dataGridView1.Columns[3], ListSortDirection.Descending);
                        break;
                    case "Статус":
                        dataGridView1.Sort(dataGridView1.Columns[4], ListSortDirection.Descending);
                        break;
                }
            }

            else if (ascOrders.Checked)
            {
                switch (comboBox1.Text)
                {
                    case "id":
                        dataGridView1.Sort(dataGridView1.Columns[0], ListSortDirection.Ascending);
                        break;
                    case "id клиента":
                        dataGridView1.Sort(dataGridView1.Columns[1], ListSortDirection.Ascending);
                        break;
                    case "id продукта":
                        dataGridView1.Sort(dataGridView1.Columns[2], ListSortDirection.Ascending);
                        break;
                    case "Количество":
                        dataGridView1.Sort(dataGridView1.Columns[3], ListSortDirection.Ascending);
                        break;
                    case "Статус":
                        dataGridView1.Sort(dataGridView1.Columns[4], ListSortDirection.Ascending);
                        break;
                }
            }
        }

        private void descOrders_CheckedChanged(object sender, EventArgs e)
        {
            if (descOrders.Checked)
                ascOrders.Checked = false;
            else if (ascOrders.Checked)
                descOrders.Checked = false;
        }

        private void find_id_orders_TextChanged(object sender, EventArgs e)
        {
            if (find_id_orders.Text == "")
                findOrders.Enabled = false;
            else findOrders.Enabled = true;
        }
        private void addOperations_Click(object sender, EventArgs e) //ВТОРАЯ ТАБЛИЦА
        {
            string orderId = operation_order_id.Text;
            string productId = operation_product_id.Text;
            string type = operation_type.Text;
            DateTime endDate = dateTimePicker1.Value;
            string emp = operation_resp.Text;
            string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Insert into Production_Operations([order_id], [product_id], [operation_type], [end_date], [responsible_employee_id]) VALUES(@id, @product_id, @type, @date, @emp);";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@id", orderId);
            cmd1.Parameters.AddWithValue("@product_id", productId);
            cmd1.Parameters.AddWithValue("@type", type);
            cmd1.Parameters.AddWithValue("@date", endDate);
            cmd1.Parameters.AddWithValue("@emp", emp);
            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();
            this.production_OperationsTableAdapter.Fill(this.практика_КудаевDataSetProduction_Operations.Production_Operations);
            operation_id.Clear();
            operation_order_id.Clear();
            operation_product_id.Clear();
            operation_type.Clear();
            operation_resp.Clear();
            dateTimePicker1.Value = DateTime.Now;
        }

        private void editOperations_Click(object sender, EventArgs e)
        {
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
                {
                    if (dataGridView2.Rows[i].Cells[0].Value.ToString() == operation_id.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Производственная операция не найдена!");
                string id = operation_id.Text;
                string orderId = operation_order_id.Text;
                string productId = operation_product_id.Text;
                string type = operation_type.Text;
                DateTime endDate = dateTimePicker1.Value;
                string emp = operation_resp.Text;
                string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDel = $"Update Production_Operations set [order_id] = @order_id, [product_id] = @product_id, [operation_type] = @type, [end_date] = @date, [responsible_employee_id] = @emp where [id] = @id;";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                cmd1.Parameters.AddWithValue("@id", id);
                cmd1.Parameters.AddWithValue("@order_id", orderId);
                cmd1.Parameters.AddWithValue("@product_id", productId);
                cmd1.Parameters.AddWithValue("@type", type);
                cmd1.Parameters.AddWithValue("@date", endDate);
                cmd1.Parameters.AddWithValue("@emp", emp);
                MyConnection.Open();
                cmd1.ExecuteNonQuery();
                MyConnection.Close();
                this.production_OperationsTableAdapter.Fill(this.практика_КудаевDataSetProduction_Operations.Production_Operations);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            operation_id.Clear();
            operation_order_id.Clear();
            operation_product_id.Clear();
            operation_type.Clear();
            operation_resp.Clear();
            dateTimePicker1.Value = DateTime.Now;
        }

        private void deleteOperations_Click(object sender, EventArgs e)
        {
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
                {
                    if (dataGridView2.Rows[i].Cells[0].Value.ToString() == operation_id.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Производственная операция не найдена!");
                string id = operation_id.Text;
                string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDel = "Delete from Production_Operations where [id] = @id";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                cmd1.Parameters.AddWithValue("@id", id);
                MyConnection.Open();
                cmd1.ExecuteNonQuery();
                MyConnection.Close();
                this.production_OperationsTableAdapter.Fill(this.практика_КудаевDataSetProduction_Operations.Production_Operations);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            operation_id.Clear();
            operation_order_id.Clear();
            operation_product_id.Clear();
            operation_type.Clear();
            operation_resp.Clear();
            dateTimePicker1.Value = DateTime.Now;
        }

        private void descOperations_CheckedChanged(object sender, EventArgs e)
        {
            if (descOperations.Checked)
                ascOperations.Checked = false;
            else if (descOperations.Checked)
                ascOperations.Checked = false;
        }

        private void sortOperations_Click(object sender, EventArgs e)
        {
            if (descOperations.Checked)
            {
                switch (comboBox2.Text)
                {
                    case "id":
                        dataGridView2.Sort(dataGridView2.Columns[0], ListSortDirection.Descending);
                        break;
                    case "id заказа":
                        dataGridView2.Sort(dataGridView2.Columns[1], ListSortDirection.Descending);
                        break;
                    case "id продукта":
                        dataGridView2.Sort(dataGridView2.Columns[2], ListSortDirection.Descending);
                        break;
                    case "Тип операции":
                        dataGridView2.Sort(dataGridView2.Columns[3], ListSortDirection.Descending);
                        break;
                    case "Дата окончания":
                        dataGridView2.Sort(dataGridView2.Columns[4], ListSortDirection.Descending);
                        break;
                    case "Ответственный сотрудник":
                        dataGridView2.Sort(dataGridView2.Columns[5], ListSortDirection.Descending);
                        break;
                }
            }

            else if (ascOperations.Checked)
            {
                switch (comboBox2.Text)
                {
                    case "id":
                        dataGridView2.Sort(dataGridView2.Columns[0], ListSortDirection.Ascending);
                        break;
                    case "id заказа":
                        dataGridView2.Sort(dataGridView2.Columns[1], ListSortDirection.Ascending);
                        break;
                    case "id продукта":
                        dataGridView2.Sort(dataGridView2.Columns[2], ListSortDirection.Ascending);
                        break;
                    case "Тип операции":
                        dataGridView2.Sort(dataGridView2.Columns[3], ListSortDirection.Ascending);
                        break;
                    case "Дата окончания":
                        dataGridView2.Sort(dataGridView2.Columns[4], ListSortDirection.Ascending);
                        break;
                    case "Ответственный сотрудник":
                        dataGridView2.Sort(dataGridView2.Columns[5], ListSortDirection.Ascending);
                        break;
                }
            }
        }

        private void find_id_operations_TextChanged(object sender, EventArgs e)
        {
            if (find_id_operations.Text == "")
                findOperations.Enabled = false;
            else findOperations.Enabled = true;
        }

        private void findOperations_Click(object sender, EventArgs e)
        {
            dataGridView2.ClearSelection();
            string searchValue = find_id_operations.Text;
            dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
                {
                    if (dataGridView2.Rows[i].Cells[0].Value.ToString() == find_id_operations.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Производственная операция не найдена!");
                foreach (DataGridViewRow row in dataGridView2.Rows)
                {
                    if (row.Cells[0].Value.ToString().TrimEnd() == searchValue)
                    {
                        row.Selected = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            dataGridView2.Refresh();
            find_id_operations.Clear();
            findOperations.Enabled = false;
        }

        private void addStocks_Click(object sender, EventArgs e) //ТРЕТЬЯ ТАБЛИЦА
        {
            string productId = stocks_product_id.Text;
            string quan = stocks_quantity.Text;         
            string loc = stocks_location.Text;
            string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Insert into Warehouse_Stocks([product_id], [quantity], [location]) VALUES(@product_id, @quan, @loc);";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@product_id", productId);
            cmd1.Parameters.AddWithValue("@quan", quan);
            cmd1.Parameters.AddWithValue("@loc", loc);
            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();
            this.warehouse_StocksTableAdapter.Fill(this.практика_КудаевDataSetWarehouse_Stocks.Warehouse_Stocks);
            stocks_id.Clear();
            stocks_product_id.Clear();
            stocks_quantity.Clear();
            stocks_location.Clear();
        }

        private void editStocks_Click(object sender, EventArgs e)
        {
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView3.Rows.Count - 1; i++)
                {
                    if (dataGridView3.Rows[i].Cells[0].Value.ToString() == stocks_id.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Склад не найден!");
                string id = stocks_id.Text;
                string productId = stocks_product_id.Text;
                string quan = stocks_quantity.Text;
                string loc = stocks_location.Text;
                string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDel = $"Update Warehouse_Stocks set [product_id] = @product_id, [quantity] = @quan, [location] = @loc where [id] = @id;";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                cmd1.Parameters.AddWithValue("@id", id);
                cmd1.Parameters.AddWithValue("@product_id", productId);
                cmd1.Parameters.AddWithValue("@quan", quan);
                cmd1.Parameters.AddWithValue("@loc", loc);
                MyConnection.Open();
                cmd1.ExecuteNonQuery();
                MyConnection.Close();
                this.warehouse_StocksTableAdapter.Fill(this.практика_КудаевDataSetWarehouse_Stocks.Warehouse_Stocks);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            stocks_id.Clear();
            stocks_product_id.Clear();
            stocks_quantity.Clear();
            stocks_location.Clear();
        }

        private void deleteStocks_Click(object sender, EventArgs e)
        {
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView3.Rows.Count - 1; i++)
                {
                    if (dataGridView3.Rows[i].Cells[0].Value.ToString() == stocks_id.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Склад не найден!");
                string id = stocks_id.Text;
                string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDel = "Delete from Warehouse_Stocks where [id] = @id";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                cmd1.Parameters.AddWithValue("@id", id);
                MyConnection.Open();
                cmd1.ExecuteNonQuery();
                MyConnection.Close();
                this.warehouse_StocksTableAdapter.Fill(this.практика_КудаевDataSetWarehouse_Stocks.Warehouse_Stocks);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            stocks_id.Clear();
            stocks_product_id.Clear();
            stocks_quantity.Clear();
            stocks_location.Clear();
        }
        private void sortStocks_Click(object sender, EventArgs e)
        {
            if (descStocks.Checked)
            {
                switch (comboBox3.Text)
                {
                    case "id":
                        dataGridView3.Sort(dataGridView3.Columns[0], ListSortDirection.Descending);
                        break;
                    case "id продукта":
                        dataGridView3.Sort(dataGridView3.Columns[1], ListSortDirection.Descending);
                        break;
                    case "Количество":
                        dataGridView3.Sort(dataGridView3.Columns[2], ListSortDirection.Descending);
                        break;
                    case "Адрес":
                        dataGridView3.Sort(dataGridView3.Columns[3], ListSortDirection.Descending);
                        break;
                }
            }

            else if (ascStocks.Checked)
            {
                switch (comboBox3.Text)
                {
                    case "id":
                        dataGridView3.Sort(dataGridView3.Columns[0], ListSortDirection.Ascending);
                        break;
                    case "id продукта":
                        dataGridView3.Sort(dataGridView3.Columns[1], ListSortDirection.Ascending);
                        break;
                    case "Количество":
                        dataGridView3.Sort(dataGridView3.Columns[2], ListSortDirection.Ascending);
                        break;
                    case "Адрес":
                        dataGridView3.Sort(dataGridView3.Columns[3], ListSortDirection.Ascending);
                        break;
                }
            }
        }

        private void descStocks_CheckedChanged(object sender, EventArgs e)
        {
            if (descStocks.Checked)
                ascStocks.Checked = false;
            else if (descStocks.Checked)
                ascStocks.Checked = false;
        }

        private void findStocks_Click(object sender, EventArgs e)
        {
            dataGridView3.ClearSelection();
            string searchValue = find_id_stocks.Text;
            dataGridView3.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView3.Rows.Count - 1; i++)
                {
                    if (dataGridView3.Rows[i].Cells[0].Value.ToString() == find_id_stocks.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Склад не найден!");
                foreach (DataGridViewRow row in dataGridView3.Rows)
                {
                    if (row.Cells[0].Value.ToString().TrimEnd() == searchValue)
                    {
                        row.Selected = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            dataGridView3.Refresh();
            find_id_stocks.Clear();
            findStocks.Enabled = false;
        }

        private void find_id_stocks_TextChanged(object sender, EventArgs e)
        {
            if (find_id_stocks.Text == "")
                findStocks.Enabled = false;
            else findStocks.Enabled = true;
        }

        private void addUsers_Click(object sender, EventArgs e) //ЧЕТВЁРТАЯ ТАБЛИЦА
        {
            string role = user_role.Text;
            string log = user_login.Text;
            string pass = user_password.Text;
            string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Insert into Users([role], [login], [password]) VALUES(@role, @log, @pass);";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@role", role);
            cmd1.Parameters.AddWithValue("@log", log);
            cmd1.Parameters.AddWithValue("@pass", pass);
            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();
            this.usersTableAdapter.Fill(this.практика_КудаевDataSetUsers1.Users);
            user_id.Clear();
            user_role.Text = "";
            user_login.Clear();
            user_password.Clear();
        }

        private void editUsers_Click(object sender, EventArgs e)
        {
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView4.Rows.Count - 1; i++)
                {
                    if (dataGridView4.Rows[i].Cells[0].Value.ToString() == user_id.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Пользователь не найден!");
                string id = user_id.Text;
                string role = user_role.Text;
                string log = user_login.Text;
                string pass = user_password.Text;
                string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDel = $"Update Users set [role] = @role, [login] = @log, [password] = @pass where [id] = @id;";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                cmd1.Parameters.AddWithValue("@id", id);
                cmd1.Parameters.AddWithValue("@role", role);
                cmd1.Parameters.AddWithValue("@log", log);
                cmd1.Parameters.AddWithValue("@pass", pass);
                MyConnection.Open();
                cmd1.ExecuteNonQuery();
                MyConnection.Close();
                this.usersTableAdapter.Fill(this.практика_КудаевDataSetUsers1.Users);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            user_id.Clear();
            user_role.Text = "";
            user_login.Clear();
            user_password.Clear();
        }

        private void deleteUsers_Click(object sender, EventArgs e)
        {
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView4.Rows.Count - 1; i++)
                {
                    if (dataGridView4.Rows[i].Cells[0].Value.ToString() == user_id.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Пользователь не найден!");
                string id = user_id.Text;
                string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDel = "Delete from Users where [id] = @id";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                cmd1.Parameters.AddWithValue("@id", id);
                MyConnection.Open();
                cmd1.ExecuteNonQuery();
                MyConnection.Close();
                this.usersTableAdapter.Fill(this.практика_КудаевDataSetUsers1.Users);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            user_id.Clear();
            user_role.Text = "";
            user_login.Clear();
            user_password.Clear();
        }

        private void descUsers_CheckedChanged(object sender, EventArgs e)
        {
            if (descUsers.Checked)
                ascUsers.Checked = false;
            else if (ascUsers.Checked)
                descUsers.Checked = false;
        }

        private void sortUsers_Click(object sender, EventArgs e)
        {
            if (descUsers.Checked)
            {
                switch (comboBox4.Text)
                {
                    case "id":
                        dataGridView4.Sort(dataGridView4.Columns[0], ListSortDirection.Descending);
                        break;
                    case "Роль":
                        dataGridView4.Sort(dataGridView4.Columns[1], ListSortDirection.Descending);
                        break;
                    case "Логин":
                        dataGridView4.Sort(dataGridView4.Columns[2], ListSortDirection.Descending);
                        break;
                    case "Пароль":
                        dataGridView4.Sort(dataGridView4.Columns[3], ListSortDirection.Descending);
                        break;
                }
            }

            else if (ascUsers.Checked)
            {
                switch (comboBox4.Text)
                {
                    case "id":
                        dataGridView4.Sort(dataGridView4.Columns[0], ListSortDirection.Ascending);
                        break;
                    case "Роль":
                        dataGridView4.Sort(dataGridView4.Columns[1], ListSortDirection.Ascending);
                        break;
                    case "Логин":
                        dataGridView4.Sort(dataGridView4.Columns[2], ListSortDirection.Ascending);
                        break;
                    case "Пароль":
                        dataGridView4.Sort(dataGridView4.Columns[3], ListSortDirection.Ascending);
                        break;
                }
            }
        }

        private void find_id_users_TextChanged(object sender, EventArgs e)
        {
            if (find_id_users.Text == "")
                findUsers.Enabled = false;
            else findUsers.Enabled = true;
        }

        private void findUsers_Click(object sender, EventArgs e)
        {
            dataGridView4.ClearSelection();
            string searchValue = find_id_users.Text;
            dataGridView4.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView4.Rows.Count - 1; i++)
                {
                    if (dataGridView4.Rows[i].Cells[0].Value.ToString() == find_id_users.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Пользователь не найден!");
                foreach (DataGridViewRow row in dataGridView4.Rows)
                {
                    if (row.Cells[0].Value.ToString().TrimEnd() == searchValue)
                    {
                        row.Selected = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            dataGridView4.Refresh();
            find_id_users.Clear();
            findUsers.Enabled = false;
        }

        private void addProducts_Click(object sender, EventArgs e) //ПЯТАЯ ТАБЛИЦА
        {
            string name = product_name.Text;
            string desc = product_desc.Text;
            string price = product_price.Text;
            string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Insert into Products([name], [description], [price]) VALUES(@name, @desc, @price);";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@name", name);
            cmd1.Parameters.AddWithValue("@desc", desc);
            cmd1.Parameters.AddWithValue("@price", price);
            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();
            this.productsTableAdapter.Fill(this.практика_КудаевDataSetProducts.Products);
            product_id.Clear();
            product_name.Clear();
            product_desc.Clear();
            product_price.Clear();
        }

        private void editProducts_Click(object sender, EventArgs e)
        {
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView5.Rows.Count - 1; i++)
                {
                    if (dataGridView5.Rows[i].Cells[0].Value.ToString() == product_id.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Продукт не найден!");
                string id = product_id.Text;
                string name = product_name.Text;
                string desc = product_desc.Text;
                string price = product_price.Text;
                string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDel = $"Update Products set [name] = @name, [description] = @desc, [price] = @price where [id] = @id;";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                cmd1.Parameters.AddWithValue("@id", id);
                cmd1.Parameters.AddWithValue("@name", name);
                cmd1.Parameters.AddWithValue("@desc", desc);
                cmd1.Parameters.AddWithValue("@price", price);
                MyConnection.Open();
                cmd1.ExecuteNonQuery();
                MyConnection.Close();
                this.productsTableAdapter.Fill(this.практика_КудаевDataSetProducts.Products);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            product_id.Clear();
            product_name.Clear();
            product_desc.Clear();
            product_price.Clear();
        }

        private void deleteProducts_Click(object sender, EventArgs e)
        {
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView5.Rows.Count - 1; i++)
                {
                    if (dataGridView5.Rows[i].Cells[0].Value.ToString() == product_id.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Продукт не найден!");
                string id = product_id.Text;
                string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDel = "Delete from Products where [id] = @id";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                cmd1.Parameters.AddWithValue("@id", id);
                MyConnection.Open();
                cmd1.ExecuteNonQuery();
                MyConnection.Close();
                this.productsTableAdapter.Fill(this.практика_КудаевDataSetProducts.Products);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            product_id.Clear();
            product_name.Clear();
            product_desc.Clear();
            product_price.Clear();
        }

        private void descProducts_CheckedChanged(object sender, EventArgs e)
        {
            if (descProducts.Checked)
                ascProducts.Checked = false;
            else if (ascProducts.Checked)
                descProducts.Checked = false;
        }

        private void sortProducts_Click(object sender, EventArgs e)
        {
            if (descProducts.Checked)
            {
                switch (comboBox5.Text)
                {
                    case "id":
                        dataGridView5.Sort(dataGridView5.Columns[0], ListSortDirection.Descending);
                        break;
                    case "Название":
                        dataGridView5.Sort(dataGridView5.Columns[1], ListSortDirection.Descending);
                        break;
                    case "Описание":
                        dataGridView5.Sort(dataGridView5.Columns[2], ListSortDirection.Descending);
                        break;
                    case "Цена":
                        dataGridView5.Sort(dataGridView5.Columns[3], ListSortDirection.Descending);
                        break;
                }
            }

            else if (ascProducts.Checked)
            {
                switch (comboBox5.Text)
                {
                    case "id":
                        dataGridView5.Sort(dataGridView5.Columns[0], ListSortDirection.Ascending);
                        break;
                    case "Название":
                        dataGridView5.Sort(dataGridView5.Columns[1], ListSortDirection.Ascending);
                        break;
                    case "Описание":
                        dataGridView5.Sort(dataGridView5.Columns[2], ListSortDirection.Ascending);
                        break;
                    case "Цена":
                        dataGridView5.Sort(dataGridView5.Columns[3], ListSortDirection.Ascending);
                        break;
                }
            }
        }

        private void find_id_products_TextChanged(object sender, EventArgs e)
        {
            if (find_id_products.Text == "")
                findProducts.Enabled = false;
            else findProducts.Enabled = true;
        }

        private void findProducts_Click(object sender, EventArgs e)
        {
            dataGridView5.ClearSelection();
            string searchValue = find_id_products.Text;
            dataGridView5.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView5.Rows.Count - 1; i++)
                {
                    if (dataGridView5.Rows[i].Cells[0].Value.ToString() == find_id_products.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Продукт не найден!");
                foreach (DataGridViewRow row in dataGridView5.Rows)
                {
                    if (row.Cells[0].Value.ToString().TrimEnd() == searchValue)
                    {
                        row.Selected = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            dataGridView5.Refresh();
            find_id_products.Clear();
            findProducts.Enabled = false;
        }

        private void addPurchases_Click(object sender, EventArgs e)
        {
            DateTime purchaseDate = dateTimePicker2.Value;
            DateTime del = dateTimePicker3.Value;
            string sup = purchase_sup.Text;
            string tot = purchase_total.Text;
            string product_id = purchase_product_id.Text;
            string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"INSERT INTO Purchases ([purchase_date], [purchase_delivery], [supplier], [total_cost], [total_items], [product_id]) SELECT @date, @del, @sup, p.price* @tot, @tot, @product_id FROM products p WHERE p.id = @product_id;";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@date", purchaseDate);
            cmd1.Parameters.AddWithValue("@del", del);
            cmd1.Parameters.AddWithValue("@sup", sup);
            cmd1.Parameters.AddWithValue("@tot", tot);
            cmd1.Parameters.AddWithValue("@product_id", product_id);
            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();
            this.purchasesTableAdapter.Fill(this.практика_КудаевDataSetPurchases.Purchases);
            purchase_id.Clear();
            purchase_sup.Clear();
            purchase_total.Clear();
            purchase_product_id.Clear();
            dateTimePicker2.Value = DateTime.Now;
            dateTimePicker3.Value = DateTime.Now;
        }

        private void editPurchases_Click(object sender, EventArgs e)
        {
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView6.Rows.Count - 1; i++)
                {
                    if (dataGridView6.Rows[i].Cells[0].Value.ToString() == purchase_id.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Покупка не найдена!");
                string id = purchase_id.Text;
                DateTime purchaseDate = dateTimePicker2.Value;
                DateTime del = dateTimePicker3.Value;
                string sup = purchase_sup.Text;
                string tot = purchase_total.Text;
                string product_id = purchase_product_id.Text;
                string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDel = $"UPDATE p SET p.purchase_date = @date, p.purchase_delivery = @del, p.supplier = @sup, p.total_items = @tot, p.product_id = @product_id, p.total_cost = pr.price * @tot FROM purchases p INNER JOIN products pr ON p.product_id = pr.id WHERE p.id = @id;";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                cmd1.Parameters.AddWithValue("@id", id);
                cmd1.Parameters.AddWithValue("@date", purchaseDate);
                cmd1.Parameters.AddWithValue("@del", del);
                cmd1.Parameters.AddWithValue("@sup", sup);
                cmd1.Parameters.AddWithValue("@tot", tot);
                cmd1.Parameters.AddWithValue("@product_id", product_id);
                MyConnection.Open();
                cmd1.ExecuteNonQuery();
                MyConnection.Close();
                this.purchasesTableAdapter.Fill(this.практика_КудаевDataSetPurchases.Purchases);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            purchase_id.Clear();
            purchase_sup.Clear();
            purchase_total.Clear();
            purchase_product_id.Clear();
            dateTimePicker2.Value = DateTime.Now;
            dateTimePicker3.Value = DateTime.Now;
        }

        private void deletePurchases_Click(object sender, EventArgs e)
        {
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView6.Rows.Count - 1; i++)
                {
                    if (dataGridView6.Rows[i].Cells[0].Value.ToString() == purchase_id.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Покупка не найдена!");
                string id = purchase_id.Text;
                string connectionString = @"Data Source = ADCLG1; Initial catalog=Практика_Кудаев; Integrated Security=True";
                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDel = $"Delete from Purchases where [id] = @id";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                cmd1.Parameters.AddWithValue("@id", id);
                MyConnection.Open();
                cmd1.ExecuteNonQuery();
                MyConnection.Close();
                this.purchasesTableAdapter.Fill(this.практика_КудаевDataSetPurchases.Purchases);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            purchase_id.Clear();
            purchase_sup.Clear();
            purchase_total.Clear();
            purchase_product_id.Clear();
            dateTimePicker2.Value = DateTime.Now;
            dateTimePicker3.Value = DateTime.Now;
        }

        private void descPurchases_CheckedChanged(object sender, EventArgs e)
        {
            if (descPurchases.Checked)
                ascPurchases.Checked = false;
            else if (ascPurchases.Checked)
                descPurchases.Checked = false;
        }

        private void sortPurchases_Click(object sender, EventArgs e)
        {
            if (descPurchases.Checked)
            {
                switch (comboBox6.Text)
                {
                    case "id":
                        dataGridView6.Sort(dataGridView6.Columns[0], ListSortDirection.Descending);
                        break;
                    case "Дата покупки":
                        dataGridView6.Sort(dataGridView6.Columns[1], ListSortDirection.Descending);
                        break;
                    case "Дата доставки":
                        dataGridView6.Sort(dataGridView6.Columns[2], ListSortDirection.Descending);
                        break;
                    case "Поставщик":
                        dataGridView6.Sort(dataGridView6.Columns[3], ListSortDirection.Descending);
                        break;
                    case "Вся стоимость":
                        dataGridView6.Sort(dataGridView6.Columns[4], ListSortDirection.Descending);
                        break;
                    case "Всего предметов":
                        dataGridView6.Sort(dataGridView6.Columns[5], ListSortDirection.Descending);
                        break;
                    case "id продукта":
                        dataGridView6.Sort(dataGridView6.Columns[6], ListSortDirection.Descending);
                        break;
                }
            }

            else if (ascPurchases.Checked)
            {
                switch (comboBox6.Text)
                {
                    case "id":
                        dataGridView6.Sort(dataGridView6.Columns[0], ListSortDirection.Ascending);
                        break;
                    case "Дата покупки":
                        dataGridView6.Sort(dataGridView6.Columns[1], ListSortDirection.Ascending);
                        break;
                    case "Дата доставки":
                        dataGridView6.Sort(dataGridView6.Columns[2], ListSortDirection.Ascending);
                        break;
                    case "Поставщик":
                        dataGridView6.Sort(dataGridView6.Columns[3], ListSortDirection.Ascending);
                        break;
                    case "Вся стоимость":
                        dataGridView6.Sort(dataGridView6.Columns[4], ListSortDirection.Ascending);
                        break;
                    case "Всего предметов":
                        dataGridView6.Sort(dataGridView6.Columns[5], ListSortDirection.Ascending);
                        break;
                    case "id продукта":
                        dataGridView6.Sort(dataGridView6.Columns[6], ListSortDirection.Ascending);
                        break;
                }
            }
        }

        private void find_id_purchases_TextChanged(object sender, EventArgs e)
        {
            if (find_id_purchases.Text == "")
                findPurchases.Enabled = false;
            else findPurchases.Enabled = true;
        }

        private void findPurchases_Click(object sender, EventArgs e)
        {
            dataGridView6.ClearSelection();
            string searchValue = find_id_purchases.Text;
            dataGridView6.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                int j = 0;
                for (int i = 0; i < dataGridView6.Rows.Count - 1; i++)
                {
                    if (dataGridView6.Rows[i].Cells[0].Value.ToString() == find_id_purchases.Text)
                    {
                        j++;
                        break;
                    }
                }
                if (j == 0)
                    throw new Exception("Покупка не найдена!");
                foreach (DataGridViewRow row in dataGridView6.Rows)
                {
                    if (row.Cells[0].Value.ToString().TrimEnd() == searchValue)
                    {
                        row.Selected = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            dataGridView6.Refresh();
            find_id_purchases.Clear();
            findPurchases.Enabled = false;
        }

        private void SettingsColor_Click(object sender, EventArgs e)
        {
            colorDialog1.AllowFullOpen = false;
            colorDialog1.ShowHelp = true;
            colorDialog1.Color = this.BackColor;

            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                this.BackColor = colorDialog1.Color;
                tabPage1.BackColor = colorDialog1.Color;
                tabPage2.BackColor = colorDialog1.Color;
                tabPage3.BackColor = colorDialog1.Color;
                tabPage4.BackColor = colorDialog1.Color;
                tabPage5.BackColor = colorDialog1.Color;
                tabPage6.BackColor = colorDialog1.Color;
                panel1.BackColor = colorDialog1.Color;
                panel2.BackColor = colorDialog1.Color;
                panel3.BackColor = colorDialog1.Color;
                panel4.BackColor = colorDialog1.Color;
                panel5.BackColor = colorDialog1.Color;
                panel6.BackColor = colorDialog1.Color;
            }
        }

        private void SettingsStyle_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowColor = true;
            fontDialog1.Font = panel1.Font;
            fontDialog1.Color = panel1.ForeColor;

            if (fontDialog1.ShowDialog() != DialogResult.Cancel)
            {
                Panel panel = this.panel1;
                panel.Font = fontDialog1.Font;
                panel.ForeColor = fontDialog1.Color;
                foreach (Control control in panel.Controls)
                {
                    control.Font = panel.Font;
                }
                panel = this.panel2;
                panel.Font = fontDialog1.Font;
                panel.ForeColor = fontDialog1.Color;
                foreach (Control control in panel.Controls)
                {
                    control.Font = panel.Font;
                }
                panel = this.panel3;
                panel.Font = fontDialog1.Font;
                panel.ForeColor = fontDialog1.Color;
                foreach (Control control in panel.Controls)
                {
                    control.Font = panel.Font;
                }
                panel = this.panel4;
                panel.Font = fontDialog1.Font;
                panel.ForeColor = fontDialog1.Color;
                foreach (Control control in panel.Controls)
                {
                    control.Font = panel.Font;
                }
                panel = this.panel5;
                panel.Font = fontDialog1.Font;
                panel.ForeColor = fontDialog1.Color;
                foreach (Control control in panel.Controls)
                {
                    control.Font = panel.Font;
                }
                panel = this.panel6;
                panel.Font = fontDialog1.Font;
                panel.ForeColor = fontDialog1.Color;
                foreach (Control control in panel.Controls)
                {
                    control.Font = panel.Font;
                }
                panel = this.panel7;
                panel.Font = fontDialog1.Font;
                panel.ForeColor = fontDialog1.Color;
                foreach (Control control in panel.Controls)
                {
                    control.Font = panel.Font;
                }
                ascOrders.Font = fontDialog1.Font;
                ascOrders.ForeColor = fontDialog1.Color;
                descOrders.Font = fontDialog1.Font;
                descOrders.ForeColor = fontDialog1.Color;
                ascOperations.Font = fontDialog1.Font;
                ascOperations.ForeColor = fontDialog1.Color;
                descOperations.Font = fontDialog1.Font;
                descOperations.ForeColor = fontDialog1.Color;
                ascStocks.Font = fontDialog1.Font;
                ascStocks.ForeColor = fontDialog1.Color;
                descStocks.Font = fontDialog1.Font;
                descStocks.ForeColor = fontDialog1.Color;
                ascUsers.Font = fontDialog1.Font;
                ascUsers.ForeColor = fontDialog1.Color;
                descUsers.Font = fontDialog1.Font;
                descUsers.ForeColor = fontDialog1.Color;
                ascProducts.Font = fontDialog1.Font;
                ascProducts.ForeColor = fontDialog1.Color;
                descProducts.Font = fontDialog1.Font;
                descProducts.ForeColor = fontDialog1.Color;
                ascPurchases.Font = fontDialog1.Font;
                ascPurchases.ForeColor = fontDialog1.Color;
                descPurchases.Font = fontDialog1.Font;
                descPurchases.ForeColor = fontDialog1.Color;
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            fontDialog1.ShowColor = true;
            fontDialog1.Font = panel1.Font;
            fontDialog1.Color = panel1.ForeColor;
            if (fontDialog1.ShowDialog() != DialogResult.Cancel)
            {
                addOrders.Font = fontDialog1.Font;
                addOrders.ForeColor = fontDialog1.Color;
                editOrders.Font = fontDialog1.Font;
                editOrders.ForeColor = fontDialog1.Color;
                deleteOrders.Font = fontDialog1.Font;
                deleteOrders.ForeColor = fontDialog1.Color;
                addOperations.Font = fontDialog1.Font;
                addOperations.ForeColor = fontDialog1.Color;
                editOperations.Font = fontDialog1.Font;
                editOperations.ForeColor = fontDialog1.Color;
                deleteOperations.Font = fontDialog1.Font;
                deleteOperations.ForeColor = fontDialog1.Color;
                addStocks.Font = fontDialog1.Font;
                addStocks.ForeColor = fontDialog1.Color;
                editStocks.Font = fontDialog1.Font;
                editStocks.ForeColor = fontDialog1.Color;
                deleteStocks.Font = fontDialog1.Font;
                deleteStocks.ForeColor = fontDialog1.Color;
                addUsers.Font = fontDialog1.Font;
                addUsers.ForeColor = fontDialog1.Color;
                editUsers.Font = fontDialog1.Font;
                editUsers.ForeColor = fontDialog1.Color;
                deleteUsers.Font = fontDialog1.Font;
                deleteUsers.ForeColor = fontDialog1.Color;
                addProducts.Font = fontDialog1.Font;
                addProducts.ForeColor = fontDialog1.Color;
                editProducts.Font = fontDialog1.Font;
                editProducts.ForeColor = fontDialog1.Color;
                deleteProducts.Font = fontDialog1.Font;
                deleteProducts.ForeColor = fontDialog1.Color;
                addPurchases.Font = fontDialog1.Font;
                addPurchases.ForeColor = fontDialog1.Color;
                editPurchases.Font = fontDialog1.Font;
                editPurchases.ForeColor = fontDialog1.Color;
                deletePurchases.Font = fontDialog1.Font;
                deletePurchases.ForeColor = fontDialog1.Color;
                groupBox1.Font = fontDialog1.Font;
                groupBox1.ForeColor = fontDialog1.Color;
                groupBox2.Font = fontDialog1.Font;
                groupBox2.ForeColor = fontDialog1.Color;
                groupBox3.Font = fontDialog1.Font;
                groupBox3.ForeColor = fontDialog1.Color;
                groupBox4.Font = fontDialog1.Font;
                groupBox4.ForeColor = fontDialog1.Color;
                groupBox5.Font = fontDialog1.Font;
                groupBox5.ForeColor = fontDialog1.Color;
                groupBox6.Font = fontDialog1.Font;
                groupBox6.ForeColor = fontDialog1.Color;
                groupBox7.Font = fontDialog1.Font;
                groupBox7.ForeColor = fontDialog1.Color;
                groupBox8.Font = fontDialog1.Font;
                groupBox8.ForeColor = fontDialog1.Color;
                groupBox9.Font = fontDialog1.Font;
                groupBox9.ForeColor = fontDialog1.Color;
                groupBox10.Font = fontDialog1.Font;
                groupBox10.ForeColor = fontDialog1.Color;
                groupBox11.Font = fontDialog1.Font;
                groupBox11.ForeColor = fontDialog1.Color;
                groupBox12.Font = fontDialog1.Font;
                groupBox12.ForeColor = fontDialog1.Color;
            }
        }
    }
}
