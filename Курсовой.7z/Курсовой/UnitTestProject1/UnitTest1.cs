﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Курсовой;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void NotAuthorization1()
        {
            Form1 form = new Form1();
            var exception = Assert.ThrowsException<Exception>(() => form.Check("123", "124"));
            Assert.AreEqual("Неправильный логин или пароль!", exception.Message);
        }
        [TestMethod]
        public void Client1()
        {
            Form1 form = new Form1();
            var exception = Assert.ThrowsException<Exception>(() => form.Check("client", "password3"));
            Assert.AreEqual("Неправильный логин или пароль!", exception.Message);
        }
        [TestMethod]
        public void Employee1()
        {
            Form1 form = new Form1();
            var exception = Assert.ThrowsException<Exception>(() => form.Check("employee", "password2"));
            Assert.AreEqual("Неправильный логин или пароль!", exception.Message);
        }
        [TestMethod]
        public void Admin1()
        {
            Form1 form = new Form1();
            var exception = Assert.ThrowsException<Exception>(() => form.Check("admin", "password1"));
            Assert.AreEqual("Неправильный логин или пароль!", exception.Message);
        }
        [TestMethod]
        public void CreateAndClient1()
        {
            Form1 form = new Form1();
            form.Create("123", "123");
            var exception = Assert.ThrowsException<Exception>(() => form.Check("123", "123"));
            Assert.AreEqual("Неправильный логин или пароль!", exception.Message);
        }
        [TestMethod]
        public void NonAuthorization2()
        {
            Form1 form = new Form1();
            var exception = Assert.ThrowsException<Exception>(() => form.Check("", ""));
            Assert.AreEqual("Неправильный логин или пароль!", exception.Message);
        }
        [TestMethod]
        public void Client2()
        {
            Form1 form = new Form1();
            var exception = Assert.ThrowsException<Exception>(() => form.Check("клиент", "клиент"));
            Assert.AreEqual("Неправильный логин или пароль!", exception.Message);
        }
        [TestMethod]
        public void Employee2()
        {
            Form1 form = new Form1();
            var exception = Assert.ThrowsException<Exception>(() => form.Check("сотрудник", "сотрудник"));
            Assert.AreEqual("Неправильный логин или пароль!", exception.Message);
        }
        [TestMethod]
        public void Admin2()
        {
            Form1 form = new Form1();
            var exception = Assert.ThrowsException<Exception>(() => form.Check("админ", "админ"));
            Assert.AreEqual("Неправильный логин или пароль!", exception.Message);
        }
        [TestMethod]
        public void CreateAndClient2()
        {
            Form1 form = new Form1();
            form.Create("124", "124");
            var exception = Assert.ThrowsException<Exception>(() => form.Check("124", "124"));
            Assert.AreEqual("Неправильный логин или пароль!", exception.Message);
        }
    }
}
